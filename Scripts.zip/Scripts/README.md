# APOS scripts

These were developed over 2011-2016 so there may be quite a bit of
difference in the quality. However, everything will generally work
quite well. Modern scripts that use PathWalker, bank_time,
and menu_time will work exceedingly well.

They will be enough to max your account in every skill except
Herblaw. For Herblaw, blood's scripts are the best, but these
work well: S_Use2x14Bank14, S_VialFiller

Please credit me if you redistribute these scripts. If you edit them,
leave at least a small comment "// edited by yourname".

A small number are not mine (they don't begin with S_).
Generally the actual author is in a comment in the script.

If semi-decent detection standards are one day brought to RSC, all of
these scripts will result in you getting banned. So will any other
scripts for anything remotely similar.

- Storm
