import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

public class B_CatherbyBlackDragons_Slave extends Script {

   private final int[] DROP_IDS = {526, 527, 814, 10, 37, 38, 42, 619};
   private final int[] PRAYER_POTIONS = {485, 484, 483};
   private final int[] ATTACK_POTIONS = {488, 487, 486};
   private final int[] STRENGTH_POTIONS = {494, 493, 492};

   private String DIRECTIONS = "    DIRECTIONS (read!)\n" +
           "\n" +
           "    SLAVE is the display name of the account with\n" +
           "        potions and food on it, and will distribute\n" +
           "        and collect items to/from the fighter accounts.\n" +
           "        SLAVE must have all the fighter accounts in\n" +
           "        its friends list.\n" +
           "\n" +
           "    USE_SUPERS can be left true unless you explicitly\n" +
           "        do not want to use supers. It'll disable\n" +
           "        itself if you don't have any or run out.\n" +
           "\n" +
           "    ALL FIGHTER ACCOUNTS must have SLAVE in their\n" +
           "        friends list. Will not work properly otherwise\n" +
           "\n" +
           "    SLAVE will hop to world 2 if not already there\n" +
           "        when the script starts. Slave will also fish if you\n" +
           "        put a shark tool or lobster pot in its inventory.\n" +
           "\n" +
           "    ALL FIGHTER ACCOUNTS should be started in the\n" +
           "        world you want them to stay on. They will\n" +
           "        always hop back to the world they're started\n" +
           "        on so this is important to avoid crashing\n" +
           "        yourself.\n" +
           "\n" +
           "    Script automatically turns off private chat - that\n" +
           "        being said, people you have added can still\n" +
           "        potentially sabotage you. I never had any\n" +
           "        issues with this, so I didn't implement\n" +
           "        anything to stop it. Empty your friends list\n" +
           "        or delete idiots, idk";

   private String SLAVE;
   private boolean USE_SUPERS = true;

   private boolean bank;
   private boolean tired;
   private boolean hasReportedStock;
   private boolean hasToldSlaveToBank;
   private Extension e;
   private HashMap<String, HashMap<String, Integer>> accounts;
   private HashMap<Integer, HashMap<String, Integer>> drops;
   private int world;
   private int position;
   private int[] initial_xp;
   private long time;
   private long move;
   private long checkin;
   private long wentUpstairs;
   private long shouldProbablyBank;
   private long[] screenshot;
   private String partner;
   private String trade_partner;
   private String filename;
   private String name;

   public B_CatherbyBlackDragons_Slave(Extension e) {
       super(e);
       this.e = e;
   }

   @Override
   public void init(String s) {
       if (s == null || s.isEmpty()) {
           System.out.println("Needs slaves display name as parameter - case sensitive");
           stop();
           return;
       }
       System.out.println(DIRECTIONS);
       SLAVE = s;
       position = 0;
       initial_xp = new int[SKILL.length];
       time = -1L;
       move = -1L;
       checkin = -1L;
       wentUpstairs = -1L;
       shouldProbablyBank = -1L;
       screenshot = new long[4];
       name = null;
       bank = false;
       hasReportedStock = false;
       hasToldSlaveToBank = true;
       accounts = new HashMap<>();
       drops = new HashMap<>();
       for (int drop_id : DROP_IDS) {
           addToDrops(drop_id);
       }
   }

   @Override
   public int main() {
//        if (!_isPrivateMessages()) {
//            _blockPrivateMessages(true);
//            return 500;
//        }
       if (name == null) {
           name = getPlayerName(0);
       }
       long now = System.currentTimeMillis();
       if (screenshot[0] != -1L) {
           return screenshot(now);
       }
       if (checkin == -1L || now > checkin + 900000L) {
           return checkin(now);
       }
       final int x = getX();
       final int y = getY();
       if (isFightingAccount()) {
           if (isUnderground()) {
               hasReportedStock = false;
               if (!hasToldSlaveToBank) {
                   hasToldSlaveToBank = true;
                   sendPrivateMessage("Go bank the stuff", SLAVE);
                   setFightMode();
                   return random(800, 1200);
               }
               int[] dragon = getNpcById(291);
               if (inCombat() || exists(dragon)) {
                   if (!isPrayerEnabled(12)) {
                       enablePrayer(12);
                   }
               } else {
                   if (isPrayerEnabled(12)) {
                       disablePrayer(12);
                   }
               }
               if (getHpPercent() < 60) {
                   if (inCombat()) {
                       walkTo(x, y);
                       return random(400, 600);
                   }
                   for (int i = 0; i < getInventoryCount(); i++) {
                       if (getItemCommand(i).toLowerCase(Locale.ENGLISH).equals("eat")) {
                           useItem(i);
                           return random(800, 1000);
                       }
                   }
                   goUpstairs();
                   return random(1400, 1600);
               }
               if (shouldRestorePrayer()) {
                   if (inCombat()) {
                       walkTo(x, y);
                       return random(400, 600);
                   }
                   if (drink(PRAYER_POTIONS)) {
                       return random(800, 1000);
                   }
                   goUpstairs();
                   return random(1400, 1600);
               }
               if (USE_SUPERS) {
                   if (!inCombat()) {
                       if (shouldRestoreAttack()) {
                           if (drink(ATTACK_POTIONS)) {
                               return random(800, 1000);
                           }
                       }
                       if (shouldRestoreStrength()) {
                           if (drink(STRENGTH_POTIONS)) {
                               return random(800, 1000);
                           }
                       }
                   }
               }
               if (getEmptySlots() < 1) {
                   if (inCombat()) {
                       walkTo(x, y);
                       return random(800, 1200);
                   }
                   goUpstairs();
                   return random(1400, 1600);
               }
               if (inCombat()) {
                   return random(800, 1200);
               }
               for (int i = 0; i < getGroundItemCount(); i++) {
                   int id = getGroundItemId(i);
                   if (drops.containsKey(id)) {
                       continue;
                   }
                   int price = getItemBasePriceId(id);
                   String name = getItemNameId(id).toLowerCase();
                   if (price >= 10000 || name.contains("rune ") || name.contains(" certificate") || name.contains("party hat")) {
                       addToDrops(id);
                   }
               }
               int[] drop_ids = hashMapKeysToIntArray(drops);
               int[] drop = getItemById(drop_ids);
               if (exists(drop) && distanceTo(drop[1], drop[2]) <= 3) {
                   if (inCombat()) {
                       walkTo(x, y);
                       return random(800, 1200);
                   }
                   pickupItem(drop[0], drop[1], drop[2]);
                   return random(800, 1200);
               }
               if (!inCombat()) {
                   int slot = getInventoryIndex(465);
                   if (exists(slot)) {
                       dropItem(slot);
                       return random(800, 1200);
                   }
                   if (canRestorePrayer()) {
                       if (drink(PRAYER_POTIONS)) {
                           return random(800, 1000);
                       }
                       goUpstairs();
                       return random(1400, 1600);
                   }
                   if (getHpPercent() < 80) {
                       for (int i = 0; i < getInventoryCount(); i++) {
                           if (getItemCommand(i).toLowerCase(Locale.ENGLISH).equals("eat")) {
                               useItem(i);
                               return random(800, 1000);
                           }
                       }
                       goUpstairs();
                       return random(1400, 1600);
                   }
               }
               if (exists(dragon)) {
                   attackNpc(dragon[0]);
                   return random(800, 1200);
               }
               if (x != 410 || y != 3336) {
                   walkTo(410, 3336);
                   return random(800, 1200);
               }
               return random(25, 50);
           } else {
               if (isPrayerEnabled(12)) {
                   disablePrayer(12);
                   return 1500;
               }
               if (wentUpstairs != -1L && System.currentTimeMillis() - 45000L > wentUpstairs) {
                   wentUpstairs = now;
                   hasReportedStock = false;
               }
               if (!hasReportedStock) {
                   hasReportedStock = true;
                   sendPrivateMessage("Hello there!:" + world + "," + getInventoryCount(PRAYER_POTIONS) + "," + getInventoryCount(546) + "," + getInventoryCount(ATTACK_POTIONS) + "," + getInventoryCount(STRENGTH_POTIONS), SLAVE);
                   return random(800, 1200);
               }
               if (getFatigue() > 0) {
                   useSleepingBag();
                   return 2000;
               }
               int[] drop_ids = hashMapKeysToIntArray(drops);
               if (getInventoryCount(drop_ids) > 0 || getInventoryCount(PRAYER_POTIONS) < 1 || getInventoryCount(546) < 1) {
                   if (x != 410 || y != 506) {
                       walkTo(410, 506);
                       return random(800, 1200);
                   }
                   if (isInTradeOffer()) {
                       if (getLocalTradeItemCount() < 1) {
                           for (int drop : drop_ids) {
                               int slot = getInventoryIndex(drop);
                               int amount = getInventoryCount(drop);
                               if (exists(slot)) {
                                   offerItemTrade(slot, amount);
                               }
                           }
                       }
                       if (!hasLocalAcceptedTrade()) {
                           acceptTrade();
                       }
                       return random(800, 1200);
                   }
                   if (isInTradeConfirm()) {
                       confirmTrade();
                       return random(800, 1200);
                   }
                   int[] player = getPlayerByName(SLAVE);
                   if (exists(player)) {
                       sendTradeRequest(getPlayerPID(player[0]));
                       return random(1400, 1600);
                   }
               } else if (getHpPercent() < 70) {
                   for (int i = 0; i < getInventoryCount(); i++) {
                       if (getItemCommand(i).toLowerCase(Locale.ENGLISH).equals("eat")) {
                           useItem(i);
                           return random(1400, 1600);
                       }
                   }
               } else if (shouldRestorePrayer()) {
                   for (final int potion : PRAYER_POTIONS) {
                       int slot = getInventoryIndex(potion);
                       if (exists(slot)) {
                           useItem(slot);
                           return random(1400, 1600);
                       }
                   }
               } else {
                   goDownstairs();
                   hasToldSlaveToBank = false;
                   String importantCalculations = "265 + 148 + 27 + 82 + 646 + 32";
                   if (importantCalculations.isEmpty()) {
                       return random(1400, 1600);
                   }
                   return random(1400, 1600);
               }
               return random(800, 1200);
           }
       } else {
           if (getFatigue() > 90 || tired) {
               useSleepingBag();
               tired = false;
               return 1000;
           }
           int slot = getInventoryIndex(372, 545);
           if (slot != -1) {
               dropItem(slot);
               return random(800, 1200);
           }
           if (move != -1L) {
               if (System.currentTimeMillis() - 5000L > move) {
                   move = -1L;
               } else {
                   walkTo(x, y - 1);
               }
               return random(800, 1200);
           }
           int things = 6;
           if (USE_SUPERS) {
               things = 8;
           }
           if (shouldProbablyBank == -1L && getInventoryCount() != things + getInventoryCount(372, 375, 379, 545, 1263)) {
               shouldProbablyBank = System.currentTimeMillis();
           }
           if (getInventoryCount() == things + getInventoryCount(372, 375, 379, 545, 1263)) {
               shouldProbablyBank = -1L;
           }
           if (shouldProbablyBank != -1L && System.currentTimeMillis() - 60000L > shouldProbablyBank) {
               bank = true;
           }
           if (bank) {
               if (isQuestMenu()) {
                   answer(0);
                   return 5000;
               }
               if (isBanking()) {
                   for (int i = 0; i < getInventoryCount(); i++) {
                       int id = getInventoryId(i);
                       if (id == 375 || id == 376 || id == 379 || id == 1263) {
                           continue;
                       }
                       if (!drops.containsKey(id)) {
                           addToDrops(id);
                       }
                       HashMap<String, Integer> hm = drops.get(id);
                       if (hm.get("Initial") == -1) {
                           hm.put("Initial", bankCount(id));
                           drops.put(id, hm);
                       }
                       if (id == 546 || id == 483 || id == 486 || id == 492) {
                           continue;
                       }
                       int amount = getInventoryCount(id);
                       deposit(id, amount);
                       return random(800, 1200);
                   }
                   int amount = getInventoryCount(546);
                   if (amount < 3) {
                       if (bankCount(546) < 3) {
                           stop();
                       }
                       withdraw(546, 3 - amount);
                       return random(800, 1200);
                   } else if (amount > 3) {
                       deposit(546, amount - 3);
                       return random(800, 1200);
                   }
                   amount = getInventoryCount(483);
                   if (amount < 3) {
                       if (bankCount(483) < 1) {
                           stop();
                       }
                       withdraw(483, 3 - amount);
                       return random(800, 1200);
                   } else if (amount > 3) {
                       deposit(483, amount - 3);
                       return random(800, 1200);
                   }
                   if (USE_SUPERS) {
                       amount = getInventoryCount(486);
                       if (amount < 1) {
                           if (bankCount(486) < 1) {
                               USE_SUPERS = false;
                               return random(800, 1200);
                           }
                           withdraw(486, 1 - amount);
                           return random(800, 1200);
                       } else if (amount > 1) {
                           deposit(486, amount - 1);
                           return random(800, 1200);
                       }
                       amount = getInventoryCount(492);
                       if (amount < 1) {
                           if (bankCount(492) < 1) {
                               USE_SUPERS = false;
                               return random(800, 1200);
                           }
                           withdraw(492, 1 - amount);
                           return random(800, 1200);
                       } else if (amount > 1) {
                           deposit(492, amount - 1);
                           return random(800, 1200);
                       }
                   }
                   amount = getInventoryCount(1263);
                   if (amount < 1) {
                       if (bankCount(1263) < 1) {
                           stop();
                       }
                       withdraw(1263, 1 - amount);
                       return random(800, 1200);
                   } else if (amount > 1) {
                       deposit(1263, amount - 1);
                       return random(800, 1200);
                   }
                   bank = false;
                   for (final int key : drops.keySet()) {
                       HashMap<String, Integer> hm = drops.get(key);
                       hm.put("Current", bankCount(key));
                       drops.put(key, hm);
                   }
                   closeBank();
                   return random(800, 1200);
               }
               int[] banker = getNpcByIdNotTalk(BANKERS);
               if (exists(banker)) {
                   talkToNpc(banker[0]);
                   return 5000;
               } else {
                   walkToBank(true);
                   return random(1400, 1600);
               }
           }
           final int fishing_level = getLevel(10);
           int fish = 0;
           if (fishing_level >= 40 && hasInventoryItem(375)) {
               fish = 1;
           }
           if (fishing_level >= 76 && hasInventoryItem(379)) {
               fish = 2;
           }
           if (fish == 1) {
               if (!isAtApproxCoords(409, 503, 1)) {
                   if (distanceTo(409, 503) < 10) {
                       walkTo(409, 503);
                   } else {
                       walkToBank(false);
                   }
                   return random(1400, 1600);
               }
           }
           if (fish == 2) {
               if (!isAtApproxCoords(406, 504, 1)) {
                   if (distanceTo(406, 504) < 10) {
                       walkTo(406, 504);
                   } else {
                       walkToBank(false);
                   }
                   return random(1400, 1600);
               }
           }
           if (isInTradeConfirm()) {
               confirmTrade();
               return random(800, 1200);
           }
           if (isInTradeOffer()) {
               HashMap<String, Integer> account = accounts.get(partner);
               int attacksNeeded = 1 - account.get("attack");
               int strengthsNeeded = 1 - account.get("strength");
               int prayersNeeded = 3 - account.get("prayer");
               int foodNeeded = 3 - account.get("food");
               if (USE_SUPERS) {
                   if (attacksNeeded > 0 && _getLocalTradeItemCount(486) < attacksNeeded) {
                       slot = getInventoryIndex(486);
                       if (exists(slot)) {
                           offerItemTrade(slot, attacksNeeded);
                           return random(400, 600);
                       }
                   }
                   if (strengthsNeeded > 0 && _getLocalTradeItemCount(492) < strengthsNeeded) {
                       slot = getInventoryIndex(492);
                       if (exists(slot)) {
                           offerItemTrade(slot, strengthsNeeded);
                           return random(400, 600);
                       }
                   }
               }
               if (prayersNeeded > 0 && _getLocalTradeItemCount(483) < prayersNeeded) {
                   slot = getInventoryIndex(483);
                   if (exists(slot)) {
                       offerItemTrade(slot, prayersNeeded);
                       return random(400, 600);
                   }
               }
               if (foodNeeded > 0 && _getLocalTradeItemCount(546) < foodNeeded) {
                   slot = getInventoryIndex(546);
                   if (exists(slot)) {
                       offerItemTrade(slot, foodNeeded);
                       return random(400, 600);
                   }
               }
               if (!hasLocalAcceptedTrade()) {
                   account.put("attack", 1);
                   account.put("strength", 1);
                   account.put("prayer", 3);
                   account.put("food", 3);
                   accounts.put(partner, account);
                   acceptTrade();
               }
               return random(800, 1200);
           }
           int[] player = getPlayerByName(partner);
           if (exists(player)) {
               sendTradeRequest(getPlayerPID(player[0]));
               return random(1400, 1600);
           } else {
               partner = trade_partner;
               int[] fishie;
               if (fish == 1) {
                   fishie = getObjectById(194);
                   if (fishie[0] != -1) {
                       atObject2(fishie[1], fishie[2]);
                       return random(800, 1200);
                   }
               }
               if (fish == 2) {
                   fishie = getObjectById(261);
                   if (fishie[0] != -1) {
                       atObject2(fishie[1], fishie[2]);
                       return random(800, 1200);
                   }
               }
           }
       }
       return random(800, 1200);
   }

   private boolean isFightingAccount() {
       return getY() >= 505;
   }

   private boolean exists(int... entity) {
       return entity[0] != -1;
   }

   private int[] hashMapKeysToIntArray(HashMap<Integer, HashMap<String, Integer>> drops) {
       int[] intArray = new int[drops.size()];
       int i = 0;
       for (final int key : drops.keySet()) {
           intArray[i] = key;
           i++;
       }
       return intArray;
   }

   private void setFightMode() {
       int fightmode = 0;
       final int att = getLevel(0);
       final int def = getLevel(1);
       final int str = getLevel(2);
       if (def < 99) fightmode = 3;
       if (att < 99) fightmode = 2;
       if (str < 99) fightmode = 1;
       if (att < 99 && def < 99 && str < 99) fightmode = 2;
       if (getFightMode() != fightmode) {
           setFightMode(fightmode);
       }
   }

   private boolean drink(int[] potions) {
       for (final int potion : potions) {
           int slot = getInventoryIndex(potion);
           if (exists(slot)) {
               useItem(slot);
               return true;
           }
       }
       return false;
   }

   private void walkToBank(boolean toBank) {
       int[] path_x = {411, 419, 431, 439};
       int[] path_y = {503, 496, 496, 495};
       if (position > path_x.length - 1 || position < 0) {
           position = 0;
       }
       if (toBank) {
           if (isAtApproxCoords(path_x[position], path_y[position], 3)) {
               position++;
           }
           if (!isReachable(path_x[position], path_y[position])) {
               int[] door = getObjectById(64);
               if (exists(door)) {
                   atObject(door[1], door[2]);
                   return;
               }
           }
           walkTo(path_x[position], path_y[position]);
       } else {
           int reverse = ((path_x.length - 1) - position);
           if (reverse < 0) {
               return;
           }
           if (isAtApproxCoords(path_x[reverse], path_y[reverse], 3)) {
               position++;
           }
           if (!isReachable(path_x[reverse], path_y[reverse])) {
               int[] door = getObjectById(64);
               if (exists(door)) {
                   atObject(door[1], door[2]);
                   return;
               }
           }
           walkTo(path_x[reverse], path_y[reverse]);
       }
   }

   private void addToDrops(int key) {
       if (drops.containsKey(key)) {
           return;
       }
       HashMap<String, Integer> hm = new HashMap<>();
       hm.put("Initial", -1);
       hm.put("Current", -1);
       drops.put(key, hm);
   }

   private int _getLocalTradeItemCount(int id) {
       int amount = 0;
       final int count = getLocalTradeItemCount();
       final boolean stacks = isItemStackableId(id);
       for (int i = 0; i < count; i++) {
           if (_getLocalTradeItemId(i) == id) {
               if (stacks) {
                   amount += _getLocalTradeItemStack(i);
               } else {
                   amount++;
               }
           }
       }
       return amount;
   }

   private int _getLocalTradeItemId(int i) {
       return e.Qf[i];
   }

   private int _getLocalTradeItemStack(int i) {
       return e.jj[i];
   }

//    private void _blockPrivateMessages(boolean paramBoolean1) {
//        e.lg = paramBoolean1 ? 1 : 0;
//        e.d(-18896, e.lg, e.nc, e.Hg, e.ec);
//    }

//    private boolean _isPrivateMessages() {
//        return e.lg == 1;
//    }

   private void println(String s) {
//        System.out.println(s);
   }

   private void stop() {
       setAutoLogin(false);
       logout();
       stopScript();
   }

   private void goUpstairs() {
       wentUpstairs = System.currentTimeMillis();
       int[] ladder = getObjectById(5);
       if (exists(ladder)) {
           atObject(ladder[1], ladder[2]);
       }
   }

   private void goDownstairs() {
       int[] ladder = getObjectById(6);
       if (exists(ladder)) {
           atObject(ladder[1], ladder[2]);
       }
   }

   private boolean canRestorePrayer() {
       int level = getLevel(5);
       int amount = (int) (7 + (level * .25));
       return level - getCurrentLevel(5) > amount;
   }

   private boolean shouldRestorePrayer() {
       int level = getLevel(5);
       int amount = (int) (7 + (level * .25));
       return level - getCurrentLevel(5) - 20 > amount;
   }

   private boolean shouldRestoreAttack() {
       return getCurrentLevel(0) < getLevel(0) + 5;
   }

   private boolean shouldRestoreStrength() {
       return getCurrentLevel(2) < getLevel(2) + 5;
   }

   private boolean isUnderground() {
       return getY() > 3000;
   }

   private int screenshot(long now) {
       if (now > screenshot[0] + 3000L) {
           screenshot[0] = -1L;
           return 50;
       }
       if (screenshot[1] == 0) {
           if (isPaintOverlay()) { // Get state of Paint
               screenshot[2] = 1L; // If it's on, remember this
               setPaintOverlay(false); // If it's on, turn it off for the screenshot
           } else {
               screenshot[2] = -1L; // If it's off, remember this
           }
           if (isRendering()) { // Get state of Graphics
               screenshot[3] = 1L; // If it's on, remember this
           } else {
               screenshot[3] = -1L; // If it's off, remember this
               setRendering(true); //If it's off, turn it on for the screenshot
           }
//            e.Hb = 20; // Mouse over skill menu  // to be removed 2.4
//            e.p = 420; // Mouse over skill menu  // to be removed 2.4
           screenshot[1] = 1;
           return 50;
       }
       if (isSkipLines()) { // to be uncommented 2.4
           setSkipLines(false);
       }
       if (now < screenshot[0] + 1000L) { // time for paint() to redraw...
           return 50;
       }
       takeScreenshot(filename); // Take screenshot
       screenshot[0] = -1L;
       screenshot[1] = 0;
       if (screenshot[2] == 1L) { // If Paint was enabled before the screenshot, turn it back on
           PaintListener.toggle();
       }
       if (screenshot[2] == 1L) { // If Paint was enabled before the screenshot, turn it back on
           setPaintOverlay(true);
       }
       if (screenshot[3] != 1L) { // If the Graphics were off before the screenshot, turn them back off
           setRendering(false);
       }
       return 50;
   }

   private int checkin(long now) {
       //called every 15 minutes, use it to post to a script listening on a web server
       if (true) { // and remove this
           checkin = now;
           return 0;
       }
       println("Checking in... ");
       if (getX() <= 0) {
           println("Failed.");
           return 1000;
       }
       try {
           StringBuilder stats = new StringBuilder();
           for (int i = 0; i < SKILL.length; i++) {
               stats.append(getXpForLevel(i));
               if (i < SKILL.length - 1) {
                   stats.append(",");
               }
           }
           URL url = new URL(
                   "https://example.com/checkin" +
                           "?name=" + URLEncoder.encode(name, "UTF-8") +
                           "&skills=" + URLEncoder.encode(stats.toString(), "UTF-8")
           );

           URLConnection conn = url.openConnection();
           conn.setConnectTimeout(5000);
           conn.setReadTimeout(5000);
           conn.getInputStream();
           println("Done.");
       } catch (IOException ioe) {
           println("Failed.");
       }
       checkin = now;
       return 0;
   }

   private int[] getXpStatistics(int skill) {
       long time = ((System.currentTimeMillis() - this.time) / 1000L);
       if (time < 1L) {
           time = 1L;
       }
       int start_xp = initial_xp[skill];
       int current_xp = getXpForLevel(skill);
       int[] intArray = new int[4];
       intArray[0] = current_xp;
       intArray[1] = start_xp;
       intArray[2] = intArray[0] - intArray[1];
       intArray[3] = (int) ((((current_xp - start_xp) * 60L) * 60L) / time);
       return intArray;
   }

   private String getRunTime() {
       long millis = (System.currentTimeMillis() - time) / 1000;
       long second = millis % 60;
       long minute = (millis / 60) % 60;
       long hour = (millis / (60 * 60)) % 24;
       long day = (millis / (60 * 60 * 24));
       if (day > 0L) return String.format("%02d days, %02d hrs, %02d mins", day, hour, minute);
       if (hour > 0L) return String.format("%02d hours, %02d mins, %02d secs", hour, minute, second);
       if (minute > 0L) return String.format("%02d minutes, %02d seconds", minute, second);
       return String.format("%02d seconds", second);
   }

   @Override
   public int[] getNpcById(int... ids) {
       final int[] npc = new int[]{
               -1, -1, -1
       };
       int max_dist = Integer.MAX_VALUE;
       for (int i = 0; i < countNpcs(); i++) {
           if (inArray(ids, getNpcId(i)) && !isNpcInCombat(i)) {
               final int x = getNpcX(i);
               final int y = getNpcY(i);
               if (x < 408 && y > 3341) {
                   continue;
               }
               final int dist = distanceTo(x, y, getX(), getY());
               if (dist < max_dist) {
                   npc[0] = i;
                   npc[1] = x;
                   npc[2] = y;
                   max_dist = dist;
               }
           }
       }
       return npc;
   }

   @Override
   public void paint() {
       int x = 110;
       int y = 10;
       drawString("Blood Black Dragons", x, y, 2, 0x00b500);
       y += 10;
       for (int i = 0; i < SKILL.length; ++i) {
           int[] xp = getXpStatistics(i);
           if (xp[2] > 100) {
               drawString(SKILL[i] + " XP Gained: " + xp[2] + " (" + xp[3] + " XP/h)", x, y, 2, 0xFFFFFF);
               y += 10;
           }
       }
       drawString("Runtime: " + getRunTime(), x, y, 2, 0xFFFFFF);
       y += 10;
       for (final int key : drops.keySet()) {
           HashMap<String, Integer> hm = drops.get(key);
           int current = hm.get("Current");
           int initial = hm.get("Initial");
           if (current == -1 || initial == -1) {
               continue;
           }
           int amount = current - initial;
           if (amount != 0) {
               drawString(getItemNameId(key) + ": " + amount, x, y, 2, 0xFFFFFF);
               y += 10;
           }
       }
   }

   @Override
   public void onTradeRequest(String name) {
       if (accounts.containsKey(name)) {
           trade_partner = name;
       }
   }

   @Override
   public void onChatMessage(String msg, String name, boolean pmod, boolean jmod) {
       super.onChatMessage(msg, name, pmod, jmod);
       if (jmod) {
           System.out.println(name + ": " + msg);
           stop();
       }
   }

   @Override
   public void onPrivateMessage(String msg, String name, boolean pmod, boolean jmod) {
       super.onPrivateMessage(msg, name, pmod, jmod);
       if (jmod) {
           System.out.println(name + ": " + msg + " (PM)");
           stop();
       }
       if (msg.contains("Hello there!")) {
           String[] stringData = msg.split(":");
           String[] stringElements = stringData[1].split(",");
           HashMap<String, Integer> account = new HashMap<>();
           account.put("prayer", Integer.parseInt(stringElements[1]));
           account.put("food", Integer.parseInt(stringElements[2]));
           account.put("attack", Integer.parseInt(stringElements[3]));
           account.put("strength", Integer.parseInt(stringElements[4]));
           accounts.put(name, account);
       }
       if (msg.contains("Go bank the stuff")) {
           bank = true;
       }
   }

   @Override
   public void onServerMessage(String s) {
       if (s.contains("been standing")) {
           move = System.currentTimeMillis();
           return;
       }
       if (s.contains("too tired")) {
           tired = true;
           return;
       }
       //screenshot start
       if (s.contains("just advanced")) {
           if (name == null) {
               name = getPlayerName(0);
           }
           screenshot[0] = System.currentTimeMillis();
           filename = new Date().getTime() + " - " + name + " - " + s;
       }
       //screenshot end
   }
}