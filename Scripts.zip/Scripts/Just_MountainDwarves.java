
import java.awt.Frame;
import java.awt.Point;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import java.util.Locale;
import java.util.Arrays;
import java.text.DecimalFormat;

public class Just_MountainDwarves extends Script {
	//Config options
	public static final int HEAL_AT = 50;				//Eat at hits level
	public static final int RUN_AT = 50;				//Hits level to run at (must be equal to or lower than HEAL_AT)
	public static final int ABORT_AT = 20;				//HP to ignore all drops and stop farming if no food remaining
	public static final int SLEEP_FATIGUE = 90;				//HP to ignore all drops and stop farming if no food remaining
	
	//Internal use
	public static final int DWARF = 356;
	public static final int MOVE_TIMEOUT = 4000;		//Seconds to wait for NPC to move before attempting to move around.
	public static final int ALCHEMY_SPELL = 28;	
	public static final int RARE_MIN_VALUE = 9000;		//Minimum item price to be considered a "rare item" (check items.txt for prices)
	public static final int DEFAULT_FOOD_AMOUNT = 20;	//Can be modified on starting script
	public static final int PICKUP_RANGE = 8;			//Actual value is PICKUP_RANGE - 1
	
	//Internal use
	private static boolean auto_fightmode;
    private static boolean restocking = false;
	private static boolean foundShieldHalf = false;
	private static boolean shieldHalfNotifyTest = false;
    private static int fight_mode;
	private static int times_banked;
	private static int[] drops_count;
	private static int food_id;
	private static int food_amount;
	private static int extra_items_count;
	private static int paint_mode;
    private static boolean[] drops_banked;
	private static boolean extra_items_banked;
	private static boolean[] req_items_checked;
	private static boolean debugging;
	private static boolean stop_next_bank;
	private static boolean full_paint;
	private static boolean foundExtraItems;
	private static boolean update_fmode;
	// private static boolean made_space;
	private static long bank_time;
	private static long menu_time;
	private static long item_time;
	private static long click_time;
	private static int[] skill_levels;
	
	//Timing
	private static final int AVG_PING = 200;
	private static final int SLEEP_MIN = 600 + AVG_PING;
	private static final int SLEEP_MAX = 800 + AVG_PING;

	//Pathwalker
	private PathWalker pw;
    private PathWalker.Path from_bank;
	private PathWalker.Path to_bank;
	
	//Points
	private static final Point bank_min		= 	new Point(437, 491);
	private static final Point bank_max		= 	new Point(443, 496);
	private static final Point area_min 	= 	new Point(390, 3295);
	private static final Point area_max 	= 	new Point(402, 3302);
	
	private String[] options = {
		"Controlled",
		"Strength",
		"Attack",
		"Defense",
		"Auto Select"	//Check if fight mode needs to be changed upon starting each trip.
	};
	
	private String[] yesNoOptions = {
		"Yes",
		"No"
	};
	
	private String[] foodOptions = {
		"Shark",
		"Lobster",
		"Swordfish"
	};
	
	private int[] foodList = {
		SHARK,
		LOBSTER,
		SWORDFISH
	};
	
	private static int startxp;
    private static long start_time;
	private static long start_time_exp;
	private static long move_time;
	private static int last_x;
	private static int last_y;
	private static long last_stuck_check_passed;
	
	private double startprayerxp = 0.0D;
	
	private final DecimalFormat int_format = new DecimalFormat("#,##0");
	private static final int
        SLEEPING_BAG = 1263,
        GNOME_BALL = 981,
		SHARK = 546,
		LOBSTER = 373,
		SWORDFISH = 370,
		NATURE_RUNE = 40,
		DSQ_HALF = 1277;		//Semicolon for last item
		
    private static final int[] items = {
		NATURE_RUNE,
		DSQ_HALF
    };
	
	private static final int[] req_items = {	//Items absolutely required for script to function. Will be kept in inventory.
		SLEEPING_BAG
	};
	
	private static final int[] no_deposit = {	//Items to be kept in inventory and never banked
	};
	
	private static final int[] drop_items = {	//Items to be dropped if in inventory
		GNOME_BALL
	};
	
    public Just_MountainDwarves(Extension e) {
        super(e);
		pw = new PathWalker(e);
    }

    public void init(String params) {
		times_banked = 0;
		startxp = 0;
		food_amount = 1;
		extra_items_count = 0;
		paint_mode = 0;
		auto_fightmode = false;
		debugging = false;
		stop_next_bank = false;
		extra_items_banked = false;
		foundExtraItems = false;
		update_fmode = false;
		last_x = -1;
		last_y = -1;
		move_time = -1L;
		bank_time = -1L;
		menu_time = -1L;
		item_time = -1L;
		click_time = -1L;
		last_stuck_check_passed = System.currentTimeMillis();
		skill_levels = new int[SKILL.length];
		
		//Pathwalker
		pw.init(null);
		from_bank 	= pw.calcPath(439, 495, 427, 456);	//Bank to stairs
		to_bank 	= pw.calcPath(427, 456, 439, 495);	//Stairs to bank
		
		for (int i = 0; i < skill_levels.length; ++i) {
			skill_levels[i] = getLevel(i);
		}
		
		if (params == null || params.isEmpty()) {
			//User input begins
			Frame frame = new Frame("Select Fighting Mode");
			String choiceF = (String) JOptionPane.showInputDialog(frame, "Combat Style (Menu 1/3):\n", "Fighting Mode Selection", JOptionPane.QUESTION_MESSAGE, null, options, options[4]);

			for (int i = 0; i < options.length; i++) {
				if (options[i].equals(choiceF)) {
					fight_mode = i;
					break;
				}
			}
			
			if (fight_mode == 4) {
				fight_mode = getNewFightMode();
				auto_fightmode = true;
				// System.out.println("Auto fight mode selection enabled!");
			}
			
			frame = new Frame("Select Food");
			int default_index = 1;
			if (hasInventoryItem(SHARK)) {
				default_index = 0;
			} else if (hasInventoryItem(SWORDFISH)) {
				default_index = 2;
			}
			String foodChoice = (String) JOptionPane.showInputDialog(frame, "Food Type (Menu 2/3):\n", "Food Type Selection", JOptionPane.PLAIN_MESSAGE, null, foodOptions, foodOptions[default_index]);
			for (int i = 0; i < foodOptions.length; i++) {
				if (foodOptions[i].equals(foodChoice)) {
					food_id = foodList[i];
				}
			}
			
			food_amount = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter food amount (Menu 3/3): ", DEFAULT_FOOD_AMOUNT));
			if (food_amount < 0 || food_amount > MAX_INV_SIZE) {
				food_amount = DEFAULT_FOOD_AMOUNT;
			}
			//User input ends
		} else if (params.equals("default")) {
			fight_mode = getNewFightMode();
			food_id = foodList[0];
			food_amount = DEFAULT_FOOD_AMOUNT;
			System.out.println("Default settings loaded");
		}
		
		start_time = start_time_exp = System.currentTimeMillis();
        startxp += getAccurateXpForLevel(0);
        startxp += getAccurateXpForLevel(1);
        startxp += getAccurateXpForLevel(2);
        startxp += getAccurateXpForLevel(3);
		startprayerxp += getAccurateXpForLevel(5);
		drops_count = new int[items.length];
        drops_banked = new boolean[items.length];
		req_items_checked = new boolean[req_items.length];
		Arrays.fill(drops_count, 0);
        Arrays.fill(drops_banked, false);
		Arrays.fill(req_items_checked, false);
    }

    public int main() {
        if (getFightMode() != fight_mode || update_fmode) {
			if (update_fmode) {
				update_fmode = false;
				fight_mode = getNewFightMode();
			}
			System.out.println("Changed fight mode from: " + getFightMode() + " to: "+ fight_mode);
            setFightMode(fight_mode);
        }
		
		if (inCombat()) {
            if (getCurrentLevel(3) <= HEAL_AT || needToPickup() || !canContinue()) {
                walkTo(getX(), getY());
				return random(400, 600);
            }
			resetLastPosition();
			return random(500, 700);
        }

		if (food_amount > 0 && getCurrentLevel(3) <= HEAL_AT) {
			int food = getInventoryIndex(food_id);
			if (food != -1) {
				useInvItem(food);
				return random(SLEEP_MIN, SLEEP_MAX);
			} else if (getY() > 3000) {
				if (!restocking) restocking = true;
				if (getCurrentLevel(3) <= ABORT_AT) {
					System.out.println("Critical Hits level!");
				}
			}
        }
		
		if (getFatigue() >= SLEEP_FATIGUE) {
			if (hasInventoryItem(1263)) {
				useSleepingBag();
				return 2000;
			}
		}
		
		if (isAtApproxCoords(128, 640, 40)) {
			return stopNow("Died. Stopping script.", false);
        }
		
		if (pw.walkPath()) {
			return 0;
		}
		
        if (isQuestMenu()) {
			menu_time = -1L;
			answer(0);
			bank_time = System.currentTimeMillis();
			return random(600, 800);
        } else if (menu_time != -1L) {
			if (System.currentTimeMillis() >= (menu_time + 8000L)) {
				menu_time = -1L;
			}
			return random(300, 400);
		}
		
		if (isBanking()) {
			bank_time = -1L;
			for (int i = 0; i < items.length; i++) {
				if (drops_banked[i]) continue;
				drops_banked[i] = true;
				int item_count = getInventoryCount(items[i]);
				int item_index = getInventoryIndex(items[i]);
				if (item_index != -1 && isItemEquipped(item_index)) { //Dont deposit equipped items! Decrement to keep worn item.
					item_count--;
				}
				if (item_count > 0) {
					if (items[i] == food_id || inArray(no_deposit, items[i])) continue;
					drops_count[i] += item_count;
					deposit(items[i], item_count);
					if (getItemBasePriceId(items[i]) >= RARE_MIN_VALUE) {
						System.out.format("Deposited %d %s\n", item_count, getItemNameId(items[i]));
						if (items[i] == DSQ_HALF || shieldHalfNotifyTest) reportShieldHalf();
					}
					return random(600, 800);
				}
			}
			//Deposit other items not specified in loot table, as long as they're not "important" items
			if (!extra_items_banked) {
				int count = getInventoryCount();
				for (int i = 0; i < count; i++) {
					int id = getInventoryId(i);
					int item_count = getInventoryCount(id);
					if (isItemEquipped(i)) {
						if (item_count == 1) continue;
						item_count--;
					}
					if (id == food_id || inArray(req_items, id) || inArray(items, id) || inArray(no_deposit, id)) continue;
					if (inArray(drop_items, id)) {
						closeBank();	//Try to let script use or drop items before attempting to bank again
						return random(800, 1000);
					}
					deposit(id, item_count);
					System.out.format("[*] Deposited %d %s\n", item_count, getItemNameId(id));
					extra_items_count++;
					if (!foundExtraItems) foundExtraItems = true;
					return random(1000, 1200);
				}
				extra_items_banked = true;
			}
			
			if (stop_next_bank) {
				stop_next_bank = false;
				Arrays.fill(drops_banked, false);		//Items will be checked next time script is started
				Arrays.fill(req_items_checked, false);
				extra_items_banked = false;
				closeBank();
				return stopNow("Stop after banking was enabled - stopping script now.", true);
			}
			
			//Check if we have the items required for the script to continue.
			for (int i = 0; i < req_items.length; i++) {
				if (req_items_checked[i]) continue;
				req_items_checked[i] = true;
				if (!hasInventoryItem(req_items[i])) {
					if (bankCount(req_items[i]) > 0) {
						withdraw(req_items[i], 1);
						return random(600, 800);
					} else {
						return stopNow("No " + getItemNameId(req_items[i]) + " in bank, stopping", false);
					}
				}
			}
			
			//withdraw food
			int withdraw_amount = food_amount - getInventoryCount(food_id);
			if (withdraw_amount > getEmptySlots()) {
				withdraw_amount = getEmptySlots();
			}
			if (withdraw_amount > 0) {
				if (bankCount(food_id) >= food_amount) {
					withdraw(food_id, withdraw_amount);
					return random(1000, 1500);
				}
				return stopNow("No more food in bank, stopping", false);
			} else if (withdraw_amount < 0) {
				deposit(food_id, getInventoryCount(food_id) - food_amount);
				return random(1000, 1500);
			}
			restocking = false;
			extra_items_banked = false;
			if (auto_fightmode) fight_mode = getNewFightMode();
			Arrays.fill(drops_banked, false);
			Arrays.fill(req_items_checked, false);
			closeBank();
			times_banked++;
			pw.setPath(from_bank);
			System.out.println("Leaving bank");
			// System.out.println("Restocking " + restocking);
			return random(600, 800);
		} else if (bank_time != -1L) {
			if (System.currentTimeMillis() >= (bank_time + 8000L)) {
				bank_time = -1L;
			}
			return random(300, 400);
		}

		int count = getInventoryCount();
		for (int i = 0; i < count; i++) {
			int id = getInventoryId(i);
			if (isItemEquipped(i) || inArray(req_items, id)) continue;
			if (inArray(drop_items, id)) {
				dropItem(i);
				return random(800, 1000);
			}
		}
		
		if (move_time != -1L) {
			if (System.currentTimeMillis() >= move_time) {
				move_around_npc();
				resetLastPosition();
				move_time = -1L;
				return random(600, 800);
			}
			return 0;
		}
		
		if (canContinue()) {
			//Main farming loop
			if (isDwarfOutside()) {
				int result = pickUpLoot();
				if (result > 0) {
					return result;
				}
				if (inValidArea(getX(), getY())) {
					boolean openedDoor = openDoor();
					if (!openedDoor) {
						walkTo(398, 3294);
					}
					return random(800, 1000);
				}
				boolean closedDoor = closeDoor();
				if (closedDoor) {
					return random(800, 1000);
				}
				boolean foundOutsider = attackOutsideDwarf();
				if (foundOutsider) {
					return random(800, 1000);
				}
			}
			if (isWithinBounds(getX(), getY(), area_min.x, area_min.y, area_max.x, area_max.y)) {
				int result = pickUpLoot();
				if (result > 0) {
					return result;
				}
				boolean attackedAdjacent = attackAdjacentEnemy();
				if (attackedAdjacent) {
					return random(600, 1000);
				}
				boolean closedDoor = closeDoor();
				if (closedDoor) {
					return random(800, 1000);
				}
				result = moveToLoot(); 
				if (result > 0) {
					return result;
				}
				boolean fightWasInitiated = attackNearestEnemy();
				if (fightWasInitiated) {
					return random(600, 1000);
				}
				return random(600, 800);
            }
			if (getY() > 3000) {
				if (getX() > 416) {
					walkTo(414, 3295);
					return random(800, 1000);
				}
				if (distanceTo(397, 3294) > 5) {
					walkTo(398, 3294);
					return random(800, 1000);
				}
				int[] doors = getObjectById(64);
				if (doors[0] != -1) {
					atObject(doors[1], doors[2]);
					return random(800, 1000);
				}
				walkTo(398, 3296);
				return random(800, 1000);
			} else if (isAtApproxCoords(426, 457, 10)) {
				int[] stairs = getObjectById(359);
				if (stairs[0] != -1) {
					atObject(stairs[1], stairs[2]);
					return random(1500, 2000);
				}
			}	
        } else {
			//Restocking
            if (isWithinBounds(getX(), getY(), bank_min.x, bank_min.y, bank_max.x, bank_max.y)) {
				// System.out.println("Restocking " + restocking);
				if (!isBanking()) {
					int banker[] = getNpcByIdNotTalk(95);
					if (banker[0] != -1) {
						if (distanceTo(banker[1], banker[2]) > 4) {
							walk_approx(banker[1], banker[2]);
							return random(800, 1000);
						}
						talkToNpc(banker[0]);
						menu_time = System.currentTimeMillis();
						return random(600, 1000);
					}
				}
            }
			if (isWithinBounds(getX(), getY(), area_min.x, area_min.y, area_max.x, area_max.y)) {
				int result = pickUpLoot();
				if (result > 0) {
					return result;
				}
				boolean openedDoor = openDoor();
				if (!openedDoor) {
					walkTo(398, 3294);
				}
				return random(800, 1000);
            }
			if (getY() > 3000) {
				if (getX() < 402) {
					boolean closedDoor = closeDoor();
					if (closedDoor) {
						return random(800, 1000);
					}
				}
				if (getX() < 416) {
					walkTo(418, 3295);
					return random(800, 1000);
				}
				int[] stairs = getObjectById(43);
				if (stairs[0] != -1) {
					if (distanceTo(stairs[1], stairs[2]) > 5) {
						walkTo(425, 3294);
						return random(800, 1000);
					}
					atObject(stairs[1], stairs[2]);
				}
				return random(1000, 1500);
			} else {
				if (isAtApproxCoords(426, 457, 10)) {
					pw.setPath(to_bank);
					System.out.println("Walking to bank");
					return random(600, 800);
				}
			}
		}
        return random(800, 1000);
    }
	
	private static int contains_index(String str, String[] options, int count) {	//Taken from S_TreeFletch
        str = str.toLowerCase(Locale.ENGLISH);
        for (int i = 0; i < count; ++i) {
            if (options[i].toLowerCase(Locale.ENGLISH).contains(str)) {
                return i;
            }
        }
        return -1;
    }
	
	private int getItemBasePriceId2 (int id) {	//Version that doesn't freak out at -1 item id
		if (id == -1) return 0;
		return getItemBasePriceId(id);
	}
	
	private int pickUpLoot() {	//Pick up close range items
		int item_count = getGroundItemCount();
		int max_dist = 2;
		int[] loot_item = new int[] {
			-1, -1, -1
		};
		for (int i = 0; i < item_count; i++) {
			int x = getItemX(i);
			int y = getItemY(i);
			if (!isReachable(x, y)) continue;
			int id = getGroundItemId(i);
			if (inArray(items, id) || getItemBasePriceId(id) >= RARE_MIN_VALUE) {
				if (canPickupItemId(id)) {
					int dist = distanceTo(x, y);
					if (dist < max_dist || (dist <= max_dist && getItemBasePriceId(id) > getItemBasePriceId2(loot_item[0]))) {
						loot_item[0] = id;
						loot_item[1] = x;
						loot_item[2] = y;
						max_dist = dist;
					}
				}
			}
		}
		if (loot_item[0] != -1) {
			if (getInventoryCount() < MAX_INV_SIZE || (isItemStackableId(loot_item[0]) && hasInventoryItem(loot_item[0]))) {
				pickupItem(loot_item[0], loot_item[1], loot_item[2]);
				return random(800, 1200);
			}
			if (makeInvSpace(loot_item[0])) return random(SLEEP_MIN, SLEEP_MAX);
		}
		return 0;
	}
	
	private int moveToLoot() {
		int item_count = getGroundItemCount();
		int max_dist = PICKUP_RANGE;
		int[] walk_to = new int[] {
			-1, -1
		};
		for (int i = 0; i < item_count; i++) {
			int id = getGroundItemId(i);
			if (getItemBasePriceId(id) >= RARE_MIN_VALUE) {
				int x = getItemX(i);
				int y = getItemY(i);
				if (inValidArea(x, y)) {
					if ((getItemBasePriceId(id) >= RARE_MIN_VALUE) && (getInventoryCount() < MAX_INV_SIZE || hasInventoryItem(food_id))) {
						walk_to[0] = x;
						walk_to[1] = y;
						break;
					}
					//Section not really needed, but kept in case user wants to pick up other loot. This script normally only picks up dragon bones or "rare" items
					if (inArray(items, id)) {
						if (getInventoryCount() < MAX_INV_SIZE || isItemStackableId(id) && hasInventoryItem(id)) {
							int dist = distanceTo(x, y);
							if (dist < max_dist) {
								walk_to[0] = x;
								walk_to[1] = y;
								if (dist == 0) break;
								max_dist = dist;
								continue;
							}
						}
					}
				}
			}
		}
		if (walk_to[0] != -1) {
			checkIfStuckNpc();
			walk_approx(walk_to[0], walk_to[1]);
			return random(800, 1000);
		}
		return 0;
	}
	
	private int[] getNearestValidNpcId(int id) {
		int[] npc = new int[] {-1, -1, -1};
		int count = countNpcs();
		int max_dist = Integer.MAX_VALUE;
		for (int i = 0; i < count; i++) {
			if (isNpcInCombat(i)) continue;
			if (getNpcId(i) == id) {
				int x = getNpcX(i);
				int y = getNpcY(i);
				int dist = distanceTo(x, y, getX(), getY());
				if (dist < max_dist && !isPlayerAt(x, y, 0) && inValidArea(x, y)) {
					npc[0] = i;
					npc[1] = x;
					npc[2] = y;
					if (dist == 0) break;
					max_dist = dist;
				}
			}
		}
		return npc;
	}
	
	private int[] getAdjacentEnemy() {
		int[] npc = new int[] {-1, -1, -1};
		int count = countNpcs();
		int max_dist = 2;
		for (int i = 0; i < count; i++) {
			if (isNpcInCombat(i)) continue;
			int x = getNpcX(i);
			int y = getNpcY(i);
			int dist = distanceTo(x, y, getX(), getY());
			if (dist < max_dist && !isPlayerAt(x, y, 0) && inValidArea(x, y)) {
				// if (inArray(new int[] {DWARF}, getNpcId(i))) {
				int npc_id = getNpcId(i);
				if (npc_id == DWARF) {
					npc[0] = i;
					npc[1] = x;
					npc[2] = y;
					if (dist == 0) break;
					max_dist = dist;
				}
			}
		}
		return npc;
	}
	
	private int[] getNearestEnemy() {
		int cur_x = getX();
		int cur_y = getY();
		int[] npc = getNearestValidNpcId(DWARF);
		if (npc[0] != -1) return npc;	//NPC pos already validated
		return new int[] {-1,-1,-1};
	}
	
	private int getFoodHealAmount(int id) {
		switch (id) {
			case SHARK:
				return 20;
			case LOBSTER:
				return 12;
			case SWORDFISH:
				return 16;
		}
		return 0;
	}
	
	public int getNewFightMode() {
		if (getLevel(2) < 99) return 1;	//If strength less than 99, use aggressive fight mode
		if (getLevel(0) < 99) return 2;	//If attack less than 99, use accurate fight mode
		if (getLevel(1) < 99) return 3;	//If defence less than 99, use defensive fight mode
		return 1;	//Default to aggressive if strength/attack/defence are 99
	}
	
	public int stopNow(String reason, boolean autologin) {
		System.out.println(reason);
		setAutoLogin(autologin);
		stopScript();
		return 0;
	}
	
	private void checkIfStuckNpc() {
		int cur_x = getX();
		int cur_y = getY();
		if (!isWalking() && isAnyNpcAt(cur_x, cur_y, 1) && cur_x == last_x && cur_y == last_y) {
			if ((System.currentTimeMillis() - last_stuck_check_passed) > MOVE_TIMEOUT) {
				move_time = System.currentTimeMillis() + random(1500, 1800);
			}
		} else {
			last_x = cur_x;
			last_y = cur_y;
			last_stuck_check_passed = System.currentTimeMillis();
		}
	}
	
	private void resetLastPosition() {
		last_x = last_y = -1;
		move_time = -1L;
		last_stuck_check_passed = System.currentTimeMillis();
	}
	
	private void reportShieldHalf() {
		if (!foundShieldHalf) {
			foundShieldHalf = true;
			System.out.println("\n\n*** Found dragon shield half! ***\n\n");
			Thread t = new Thread(new Runnable(){	//Method that doesn't freeze script and make you lose a DSQ
				public void run(){
					int input = JOptionPane.showOptionDialog(null, "Found dragon shield half!", "Rare drop!", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);
					if(input == JOptionPane.OK_OPTION) {
						foundShieldHalf = false;
					}
				}
			});
			t.start();
		}
	}
	
	private void move_around_npc() {
		if (isWalking()) return;
		int count = countNpcs();
		int p_x = getX();
		int p_y = getY();
		for (int i = 0; i < count; i++) {
			int npc_x = getNpcX(i);
			int npc_y = getNpcY(i);
			if (distanceTo(npc_x, npc_y, p_x, p_y) == 1) {
				int dir = (Math.random() < 0.5 ? 1 : -1);
				if (npc_x == p_x) {
					if (isReachable(p_x + dir, p_y)) {
						walkTo(p_x + dir, p_y);
					} else if (isReachable(p_x + dir * -1, p_y)) {
						walkTo(p_x + dir * -1, p_y);
					} else {
						walk_approx(p_x, p_y);
					}
					return;
				}
				if (npc_y == p_y) {
					if (isReachable(p_x, p_y + dir)) {
						walkTo(p_x, p_y + dir);
					} else if (isReachable(p_x, p_y + dir * -1)) {
						walkTo(p_x, p_y + dir * -1);
					} else {
						walk_approx(p_x, p_y);
					}
					return;
				}
			}
		}
	}
	
	private boolean openDoor() {
		int door = getObjectIdFromCoords(397, 3294);
		if (door == 64) {
			if (distanceTo(394, 3294) > 5) {
				if (getY() >= 3295) {
					walkTo(397, 3295);
				} else {
					walkTo(397, 3294);
				}
				return true;
			}
			atObject(397, 3294);
			return true;
		}
		return false;
	}
	
	private boolean closeDoor() {
		int door = getObjectIdFromCoords(397, 3294);
		if (door == 63) {
			if (distanceTo(394, 3294) > 5) {
				if (getY() >= 3295) {
					walkTo(397, 3295);
				} else {
					walkTo(397, 3294);
				}
				return true;
			}
			atObject2(397, 3294);
			return true;
		}
		return false;
	}
	
	private boolean canPickupItemId(int id) {
		if (getInventoryCount() < MAX_INV_SIZE || (isItemStackableId(id) && hasInventoryItem(id))) return true;
		int index = getInventoryIndex(food_id);
		if (index == -1) return false;
		int item_id = getInventoryId(index);
		if (getCurrentLevel(3) <= (getLevel(3) - getFoodHealAmount(item_id)) ||
			getItemBasePriceId(id) >=  RARE_MIN_VALUE ||
			id == DSQ_HALF) {
			return true;
		}
		return false;
	}
	
    private boolean attackNearestEnemy() {
		int[] npc = getNearestEnemy();
		if (npc[0] != -1) {
			// checkIfStuckPlayer();
			checkIfStuckNpc();
			if (distanceTo(npc[1], npc[2]) > 5) {
				walk_approx(npc[1], npc[2]);
			} else {
				attackNpc(npc[0]);
			}
            return true;
        }
        return false;
    }
	
	private boolean isPosOutside(int x, int y) {
		if (isWithinBounds(x, y, 390, 3295, 391, 3296)) return true;
		return (!isWithinBounds(x, y, area_min.x, area_min.y, area_max.x, area_max.y));
	}
	
	private boolean attackOutsideDwarf() {
		int[] npc = new int[] {-1, -1, -1};
		int count = countNpcs();
		int max_dist = Integer.MAX_VALUE;
		for (int i = 0; i < count; i++) {
			if (isNpcInCombat(i)) continue;
			if (getNpcId(i) == DWARF) {
				int x = getNpcX(i);
				int y = getNpcY(i);
				if (!isReachable(x, y)) continue;
				int dist = distanceTo(x, y, getX(), getY());
				if (dist < max_dist && !isPlayerAt(x, y, 0) && isPosOutside(x, y)) {
					npc[0] = i;
					npc[1] = x;
					npc[2] = y;
					if (dist == 0) break;
					max_dist = dist;
				}
			}
		}
		if (npc[0] != -1) {
			if (distanceTo(npc[1], npc[2]) > 5) {
				walk_approx(npc[1], npc[2]);
			} else {
				attackNpc(npc[0]);
			}
			return true;
		}
		return false;
	}
	
	private boolean attackAdjacentEnemy() {
		if (isWalking() || needToPickup() || getCurrentLevel(3) <= HEAL_AT) return false;
		int[] npc = getAdjacentEnemy();
		if (npc[0] != -1) {
            attackNpc(npc[0]);
            return true;
        }
        return false;
    }
	
	private boolean isWithinBounds(int x_test, int y_test, int x_min, int y_min, int x_max, int y_max)
	{
		if (x_test >= x_min &&
			x_test <= x_max &&
			y_test >= y_min &&
			y_test <= y_max) {
			return true;
		};
		return false;
	}
	
	private boolean isDwarfOutside() {
		int count = countNpcs();
		for (int i = 0; i < count; i++) {
			int id = getNpcId(i);
			if (id == DWARF) {
				int x = getNpcX(i);
				int y = getNpcY(i);
				if (isPosOutside(x, y)) return true;
			}
		}
		return false;
	}
	
	private boolean inValidArea(int x, int y) {
		if (!isReachable(x, y)) return false;
		if (isWithinBounds(x, y, 390, 3295, 391, 3296)) return false;
		return isWithinBounds(x, y, area_min.x, area_min.y, area_max.x, area_max.y);
	}
	
	private boolean isAnyNpcAt(int x, int y, int dist) {
		// if (isWalking()) return false;
		int count = countNpcs();
		for (int i = 0; i < count; i++) {
			int p_x = getNpcX(i);
			int p_y = getNpcY(i);
			if (isReachable(p_x, p_y) && distanceTo(p_x, p_y, x, y) <= dist) return true;
			
		}
		return false;
	}
	
	private boolean isFightingNpcId(int id) {
		int count = countNpcs();
		for (int i = 0; i < count; i++) {
			int p_id = getNpcId(i);
			if (p_id == id) {
				int p_x = getNpcX(i);
				int p_y = getNpcY(i);
				if (isNpcInCombat(i) && getX() == p_x && getY() == p_y) return true;
			}
		}
		return false;
	}
	
	private boolean isNpcAt(int id, int x, int y) {
		int count = countNpcs();
		for (int i = 0; i < count; i++) {
			int p_id = getNpcId(i);
			if (p_id == id) {
				int p_x = getNpcX(i);
				int p_y = getNpcY(i);
				if (x == p_x && y == p_y) return true;
			}
		}
		return false;
	}
	
	private boolean isNpcInCombatAt(int id, int x, int y, int dist) {
		int count = countNpcs();
		for (int i = 0; i < count; i++) {
			int p_id = getNpcId(i);
			if (p_id == id && isNpcInCombat(i)) {
				int p_x = getNpcX(i);
				int p_y = getNpcY(i);
				if (distanceTo(x, y, p_x, p_y) <= dist) return true;
			}
		}
		return false;
	}
	
	private boolean isPlayerInCombatAt(int x, int y, int dist) {	//Checks for players in combat with blue dragon within range (exclude self)
		// if (isWalking()) return false;
		int count = countPlayers();
		for (int i = 1; i < count; i++) {
			if (isPlayerInCombat(i)) {
				int p_x = getPlayerX(i);
				int p_y = getPlayerY(i);
				if (distanceTo(p_x, p_y, x, y) <= dist && isNpcInCombatAt(DWARF, p_x, p_y, 0)) return true;
			}
		}
		return false;
	}
	
	private boolean isPlayerAt(int x, int y, int dist) {
		int count = countPlayers();
		for (int i = 1; i < count; i++) {
			int p_x = getPlayerX(i);
			int p_y = getPlayerY(i);
			if (isReachable(p_x, p_y) && distanceTo(x, y, p_x, p_y) <= dist) return true;
		}
		return false;
	}
	
	private boolean makeInvSpace(int id) {
		int index = getInventoryIndex(food_id);
		if (index == -1) return false;
		int item_id = getInventoryId(index);
		if (getCurrentLevel(3) <= (getLevel(3) - getFoodHealAmount(item_id)) ||
			getItemBasePriceId(id) >=  RARE_MIN_VALUE ||
			id == DSQ_HALF) {
			// made_space = true;
			useInvItem(index);	//Dont return value returned by useInvItem - don't want to accidentally proceed to attack an enemy if we haven't actually picked up the item yet.
			return true;
		}
		return false;
	}
	
	private boolean canContinue() {
		if (getCurrentLevel(3) <= ABORT_AT) return false;
		if (needToPickup()) return true;
		if (restocking || (!hasInventoryItem(food_id) && food_amount > 0) || (getEmptySlots() == 0 && food_amount == 0)) return false;
		return true;
	}

	private boolean needToPickup() {
		if (getCurrentLevel(3) <= ABORT_AT) return false;
		int item_count = getGroundItemCount();
		boolean in_area = inValidArea(getX(), getY());
		for (int i = 0; i < item_count; i++) {
			int x = getItemX(i);
			int y = getItemY(i);
			if (in_area ? (inValidArea(x, y) && distanceTo(x, y) < PICKUP_RANGE) : x == getX() && y == getY()) {
				int id = getGroundItemId(i);
				if ((getItemBasePriceId(id) >= RARE_MIN_VALUE) && (getInventoryCount() < MAX_INV_SIZE || hasInventoryItem(food_id))) return true;
				if (inArray(items, id)) {
					if (getInventoryCount() < MAX_INV_SIZE || isItemStackableId(id) && hasInventoryItem(id)) {
						return true;
					}
				}
			}
		}
		return false;
	}
	
	private boolean useInvItem(int index) {
		if (System.currentTimeMillis() >= (item_time + 1500L)) {
			item_time = System.currentTimeMillis();
			useItem(index);
			return true;
		}
		return false;
	}
	
	private long getTime() {
        long secondsSinceStarted = ((System.currentTimeMillis() - start_time) / 1000);
        if (secondsSinceStarted <= 0) {
            return 1L;
        }
        return secondsSinceStarted;
    }

    private String getRunTime() {
        long millis = getTime();
        long second = millis % 60;
        long minute = (millis / 60) % 60;
        long hour = (millis / (60 * 60)) % 24;
        long day = (millis / (60 * 60 * 24));

        if (day > 0L) return String.format("%02d days, %02d hrs, %02d mins", day, hour, minute);
        if (hour > 0L) return String.format("%02d hours, %02d mins, %02d secs", hour, minute, second);
        if (minute > 0L) return String.format("%02d minutes, %02d seconds", minute, second);
        return String.format("%02d seconds", second);
    }

    @Override
    public void paint() {
		final int white = 0xFFFFFF;
		final int green = 0x00FF00;
		final int yellow = 0xFFFF00;
		final int red = 0xFF0000;

		int x = 12;
		int y = 50;
		
		long var1 = (System.currentTimeMillis() - start_time_exp) / 1000L;
		if (var1 < 1L) {
			var1 = 1L;
		}

		drawString("Just_MountainDwarves", x - 4, y - 17, 4, green);
		if (foundShieldHalf) {
			drawString("Found Half Dragon Square Shield!", x, y, 6, red);
		}
		if (extra_items_count > 0) {
			y += 15;
			drawString("Extra Items Banked: " + extra_items_count, x, y, 1, green);
		}
		y += 15;
		drawString("Runtime: " + getRunTime(), x, y, 1, yellow);
		y += 15;
		drawString("Combat EXP rate: " + (int)((getAccurateXpForLevel(2) + getAccurateXpForLevel(1) + getAccurateXpForLevel(0) + getAccurateXpForLevel(3) - startxp) * 60.0D * 60.0D / (double) var1) + "/h", x, y, 1, yellow);
		// y += 15;
		// drawString("Prayer XP rate: " + (int)((getAccurateXpForLevel(5) - startprayerxp) * 60.0D * 60.0D / (double) var1)+ "/h", x, y, 1, yellow);
		y += 15;
		drawString("Times banked: " + times_banked, x, y, 1, yellow);
		if (stop_next_bank) {
			y += 15;
			drawString("Stopping on next banking", x, y, 1, red);
		}
		x = 325;
		y = 50;
		if (paint_mode == 0) {
			drawString("Loot banked: ", x, y, 1, yellow);
			y += 15;
			for (int i = 0; i < items.length; ++i) {
				if (drops_count[i] <= 0) continue;
				drawString(getItemNameId(items[i]) + ": " + ifmt(drops_count[i]), x, y, 1, getItemBasePriceId(items[i]) < RARE_MIN_VALUE ? white : green);
				y += 15;
			}
		} else if (paint_mode == 1) {
			drawString("Levels gained: ", x, y, 1, yellow);
			y += 15;
			for (int i = 0; i < skill_levels.length; i++) {
				int gain = getLevel(i) - skill_levels[i];
				if (gain == 0) continue;
				drawString(String.format("%s: %d", SKILL[i], gain), x, y, 1, white);
				y += 15;
			}
		} else if (paint_mode == 2) {
			
		}
    }
    
	private static String get_time_since(long t) {	//Taken from S_Catherby
		long millis = (System.currentTimeMillis() - t) / 1000;
		long second = millis % 60;
		long minute = (millis / 60) % 60;
		long hour = (millis / (60 * 60)) % 24;
		long day = (millis / (60 * 60 * 24));

		if (day > 0L) {
			return String.format("%02d days, %02d hrs, %02d mins",
			    day, hour, minute);
		}
		if (hour > 0L) {
			return String.format("%02d hours, %02d mins, %02d secs",
			    hour, minute, second);
		}
		if (minute > 0L) {
			return String.format("%02d minutes, %02d seconds",
			    minute, second);
		}
		return String.format("%02d seconds", second);
	}
	
	private String per_hour(long count, long start_time) {	//Taken from S_Catherby
		double amount, secs;

		if (count == 0) return "0";
		amount = count * 60.0 * 60.0;
		secs = (System.currentTimeMillis() - start_time) / 1000.0;
		return int_format.format(amount / secs);
	}
	
	private String ifmt(long l) {
        return int_format.format(l);
    }
	
	@Override
	public void onServerMessage(String str)
	{
		str = str.toLowerCase(Locale.ENGLISH);
		if (str.contains("advanced")) {			//On levelup
			if (auto_fightmode && (str.contains("strength") || str.contains("attack") || str.contains("defence"))) {
				update_fmode = true;
			}
			System.out.println(str);
		} else if (str.contains("busy")) {
            menu_time = -1L;
		}
	}
	
	private void walk_approx(int x, int y) {
		int dx, dy;
		int loop = 0;
		do {
			dx = x + random(-1, 1);
			dy = y + random(-1, 1);
			if ((++loop) > 100) return;
		} while (!isReachable(dx, dy) ||
		    (dx == getX() && dy == getY()));
		walkTo(dx, dy);
	}
	
	private void walk_approx(int x, int y, int dist) {
		int dx, dy;
		int loop = 0;
		do {
			dx = x + random(-dist, dist);
			dy = y + random(-dist, dist);
			if ((++loop) > 100) return;
		} while (!isReachable(dx, dy) ||
		    (dx == getX() && dy == getY()));
		walkTo(dx, dy);
	}
	
	public void setNewFightMode(int fight_mode) {
		this.fight_mode = fight_mode;
	}
	
	public void onKeyPress(int keycode) {
		Frame frame;
		switch (keycode) {
			case KeyEvent.VK_F2:
				frame = new Frame("Select Fighting Mode");
				String choiceF = (String) JOptionPane.showInputDialog(frame, "Combat Style (Menu 1/3):\n", "Fighting Mode Selection", JOptionPane.QUESTION_MESSAGE, null, options, options[4]);

				for (int i = 0; i < options.length; i++) {
					if (options[i].equals(choiceF)) {
						fight_mode = i;
						break;
					}
				}
				
				if (fight_mode == 4) {
					fight_mode = getNewFightMode();
					this.auto_fightmode = true;
					// System.out.println("Auto fight mode selection enabled!");
				} else {
					this.auto_fightmode = false;
				}
				
				frame = new Frame("Select Food");
				int default_index = 1;
				if (hasInventoryItem(SHARK)) {
					default_index = 0;
				} else if (hasInventoryItem(SWORDFISH)) {
					default_index = 2;
				}
				String foodChoice = (String) JOptionPane.showInputDialog(frame, "Food Type (Menu 2/3):\n", "Food Type Selection", JOptionPane.PLAIN_MESSAGE, null, foodOptions, foodOptions[default_index]);
				for (int i = 0; i < foodOptions.length; i++) {
					if (foodOptions[i].equals(foodChoice)) {
						food_id = foodList[i];
						break;
					}
				}
				
				food_amount = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter food amount (Menu 3/3): ", DEFAULT_FOOD_AMOUNT));
				if (food_amount < 0 || food_amount > MAX_INV_SIZE) {
					food_amount = DEFAULT_FOOD_AMOUNT;
				}
				
				System.out.println("Settings modified!");
				
				break;
			case KeyEvent.VK_F3:
				String command = JOptionPane.showInputDialog(null, "Command: ", "");
				if (command == null || command.equals("")) {
					//Do nothing
				} else if (command.equals("stop") ||command.equals("stopnext")) {	//Stop next banking
					stop_next_bank = !stop_next_bank;
					if (stop_next_bank) {
						System.out.println("Enabled stop on next banking. Script will end after depositing all loot");
					} else {
						System.out.println("Cancelled stop on next banking. Script will continue running");
					}
				} else if (command.equals("banknow")) {
					restocking = true;
					if (stop_next_bank) stop_next_bank = false;
					System.out.println("Restocking flag set");
				} else if (command.equals("continue")) {
					restocking = false;
					stop_next_bank = false;
					System.out.println("Disabled stop flag");
				} else if (command.equals("stopnow")) {
					restocking = true;
					stop_next_bank = true;
					System.out.println("Immediate stop flag set");
				} else if (command.equals("resetstats")) {	//Reset stats
					start_time_exp = System.currentTimeMillis();
					startxp = 0;
					startprayerxp = 0;
					startxp += getAccurateXpForLevel(0);
					startxp += getAccurateXpForLevel(1);
					startxp += getAccurateXpForLevel(2);
					startxp += getAccurateXpForLevel(3);
					startprayerxp += getAccurateXpForLevel(5);
					System.out.println("Reset stats counter");
				} else if (command.equals("resetextra")) {	//Reset extra items counter
					extra_items_count = 0;
					System.out.println("Reset extra items counter");
				} else if (command.equals("dsqtest")) {	//Toggle DSQ notify test
					shieldHalfNotifyTest = !shieldHalfNotifyTest;
					if (shieldHalfNotifyTest) {
						System.out.println("Enabled DSQ notification test");
					} else {
						System.out.println("Cancelled DSQ notification test");
					}
				}
				break;
			case KeyEvent.VK_F4:
				paint_mode++;
				if (paint_mode > 2) paint_mode = 0;
				break;
			case KeyEvent.VK_F5:
				break;
			case KeyEvent.VK_F6:
				break;
			case KeyEvent.VK_F7:
				break;
			case KeyEvent.VK_F8: 
				break;
		}
    }
}
