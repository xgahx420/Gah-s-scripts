public final class Beard extends Script {

    private final Extension ex;

    public Beard(Extension ex) {
        super(ex);
        this.ex = ex;
    }

    @Override
    public void init(String params) {
        ex.Jh.b(235, 0);
        ex.Jh.f.c(2, -41);
        ex.Jh.f.c(ex.Vd, -82);
        ex.Jh.f.c(4, -109);
        ex.Jh.f.c(ex.wg, -123);
        ex.Jh.f.c(ex.ld, 36);
        ex.Jh.f.c(ex.Wg, 63);
        ex.Jh.f.c(ex.Lh, -113);
        ex.Jh.f.c(ex.hh, -63);
        ex.Jh.b(21294);
        ex.li.a(true);
        ex.Kg = false;
    }
}