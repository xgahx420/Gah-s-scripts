import javax.swing.JOptionPane;
import javax.swing.*;
import java.util.Locale;

public class ASCGiants extends Script {
    int fightMode;
    int param;
    int firebstf =0;
    int foodused =0;
    int bonesburied =0;
    int trips =0;
    int dmed =0;
    int dsq =0;
    int coin =0;
    int rbaxe =0;
    int r2h =0;
    int blood =0;
    int rkite =0;
    int teeth =0;
    int loop =0;
    int law =0;
    int fire =0;
    int rscim =0;
    int adsq =0;
    int rspear =0;   
    int trip =-1;
    int[] ITEM_DROP = {-1,-1,-1};
    boolean bankingnow;
    boolean walkingnow;
    boolean fightingnow;

    // Drops
    // High = run from combat, eat food to pickup. Ordered by priority
    // Medium = eat food to pickup, but don't run from combat. Will pick closest.
    // Low = pickup if room and not in combat, will burry bones if possible. Will pick closest
    int[] HIGH_VALUE_DROPS = { 795, 1277, 1092, 81, 405, 93, 404, 526, 527, 523, 542, 403, 400, 402, 408 };
    int[] MEDIUM_VALUE_DROPS = { 619, 373, 42, 398, 517, 518, 520 };
    int[] LOW_VALUE_DROPS =  { 413, 31, 615, 10 };

    // Items we don't have special bank rules for, just bank it all.
    int[] BANK_ALL = { 795, 1277, 81, 405, 93, 404, 526, 527, 523, 542, 403, 400, 402, 619, 373, 42, 398, 1092, 413, 31, 615, 10, 408, 517, 518, 520};
    
    public ASCGiants (Extension e)

    {
        super(e);
    }

    public void init( String params )
    {
        Object[] options = {"Bank", "Walking", "Fighting"};
        String param = (String)JOptionPane.showInputDialog(null, "Where are we starting?", "Fire Giants", JOptionPane.PLAIN_MESSAGE, null, options, options[2]);
        Object[] optionss = {"Attack", "Strength", "Defense", "Controlled"};
        String fightm = (String)JOptionPane.showInputDialog(null, "Choose FightMode", "Fire Giants", JOptionPane.PLAIN_MESSAGE, null, optionss, optionss[0]);

        if(param.equals("Bank")) {
            bankingnow = true;
            walkingnow = false;
            fightingnow = false;
        } else if(param.equals("Walking")) {
            bankingnow = false;
            walkingnow = true;
            fightingnow = false;
        } else if(param.equals("Fighting")) {
            bankingnow = false;
            walkingnow = false;
            fightingnow = true;
        }

        if(fightm.equals("Attack")) {
            fightMode = 2;
        } else if(fightm.equals("Strength")) {
            fightMode = 1;
        } else if(fightm.equals("Defense")) {
            fightMode = 3;
        }
    }

    public int main()
    {
        if(time == -1L) {
            time = System.currentTimeMillis();
            return 500;
        }

        if(getFightMode() != fightMode) {
            setFightMode(fightMode);
        }

        if(isBanking() && bankingnow && !walkingnow && !fightingnow)
        {
            // This is just a catch all to make sure everything is banked
            for (int bankLoop : BANK_ALL) {
                int ITEM_COUNT = getInventoryCount(bankLoop);
                
                // If the item is equipped, subtract by 1 so we don't deposit it.
                int ITEM_EQUIPPED_CHECK = getInventoryIndex(bankLoop);
                if ((ITEM_EQUIPPED_CHECK != -1) && (isItemEquipped(ITEM_EQUIPPED_CHECK))) {
                    ITEM_COUNT--;
                }

                switch (bankLoop) {
                    case 42: // Law rune
                        ITEM_COUNT--;
                        break;
                }

                if (ITEM_COUNT > 0) {
                    switch (bankLoop) {
                        case 404: // Rune kite
                            rkite += ITEM_COUNT;
                            break;
                        case 795: // D Med
                            dmed += ITEM_COUNT;
                            break;
                        case 1077: // D Sq
                            dsq += ITEM_COUNT;
                            break;
                        case 93: // Rune baxe
                            rbaxe += ITEM_COUNT;
                            break;
                        case 81: // Rune 2h
                            r2h += ITEM_COUNT;
                            break;
                        case 619: // Bloods
                            blood += ITEM_COUNT;
                            break;
                        case 10: // Coins
                            coin += ITEM_COUNT;
                            break;
                        case 526: // Teeth
                            teeth += ITEM_COUNT;
                            break;
                        case 527: // Loop
                            loop += ITEM_COUNT;
                            break;
                        case 31: // Fire
                            fire += ITEM_COUNT;
                            break;
                        case 398: // R Scim
                            rscim += ITEM_COUNT;
                            break;
                        case 1092: // R Spear
                            rspear += ITEM_COUNT;
                            break;
                        case 615:
                            firebstf += ITEM_COUNT;
                            break;
                    }
                    deposit(bankLoop, ITEM_COUNT);
                    return random(900,1200);
                }
            }

            if(getInventoryCount(42) > 1) //take law
            {
                 law += getInventoryCount(42);            
                 deposit(42,getInventoryCount(42)-1);
                 return random(1000, 1500);            
            }
            else if(getInventoryCount(42) < 1) 
            {                
                 withdraw(42,1);
                 return random(1000,1500);            
            }
            else if(getInventoryCount(33) > 5)  // take air
            {                
                 deposit(33,getInventoryCount(33)-5);
                 return random(1000, 1500);            
            }
            else if(getInventoryCount(33) < 5) 
            {                
                 withdraw(33,5-getInventoryCount(33));
                 return random(1000,1500);            
            }
            if(getInventoryCount(237) > 1) //take rope
            {                
                 deposit(237,getInventoryCount(237)-1);
                 return random(1000, 1500);            
            }
            else if(getInventoryCount(237) < 1) 
            {                
                 withdraw(237,1);
                 wearItem(getInventoryIndex(782));
                 return random(1000,1500);            
            }
            if (getInventoryCount(782) > 1) //take ammy
            {                
                 deposit(782,getInventoryCount(782)-1);
                 return random(1000, 1500);            
            } else if (getInventoryCount(782) < 1) {                
                 withdraw(782,17);
                 return random(1000,1500);            
            }
            if (getInventoryCount(373) > 0) //deposit lobby
            {                
                 deposit(373,getInventoryCount(373));
                 return random(1000, 1500);      
            }
            if (getInventoryCount(546) > 17) //take 17 sharks
            {                
                 deposit(546,getInventoryCount(546)-17);
                 return random(1000, 1500);
            } else if(getInventoryCount(546) < 17) {                
                 withdraw(546,17);
                 return random(1000,1500);
            }

            if (getLevel(3)-getCurrentLevel(3) > 25) {
                useItem(getInventoryIndex(546));
                foodused  += 1;
                return random(900, 1200);
            }
            closeBank();
            wearItem(getInventoryIndex(782));
            bankingnow = false;
            walkingnow = true;
            fightingnow = false;
            trip++;
            return random(1000,1500);
        }        
        if(bankingnow && !walkingnow && !fightingnow) // banking time
        {
            // If we still have bones in our inventory, burry them all.
            if (getInventoryIndex(413) > 0) {
                useItem(getInventoryIndex(413));
                return random(900, 1200);
            }
            
            // menu open
            if(isQuestMenu())
            {
                answer(0);
                return random(5000, 6000);
            }
            int banker[] = getNpcByIdNotTalk(95);
            if(banker[0] != -1)
            {
                talkToNpc(banker[0]);
                return 5500;
            }            
            if(getX()>=455&&getX()<467){
                walkTo(467,462);
                useItem(getInventoryIndex(373));
                return random(1000,1500);
            }
            if(getX()==467&&getY()==462) // not past gate and gate closed, open it
            {
                int[] gate = getObjectById(57);
                if(gate[0]!=-1){
                    atObject(gate[1],gate[2]);
                    walkTo(469,464);
                   return random(2500,2600);
                }
                else
                {
                    walkTo(469,464);
                    return random(150,200);
                }
            }
            if(getX()>=468&&getX()<489){
                walkTo(489,461);
                return random(1000,1500);
            }
            if(getX()>=489&&getX()<501){ //outside bank
                walkTo(501,454);
                return random(1000,1500);
            }
            int[] bankGate=getObjectById(64);
                if(bankGate[0]!=-1)
                {
                    atObject(bankGate[1],bankGate[2]);
                        return random(200,300);
                }
                else
                {
                    walkTo(501,454);  
                    return random(1000,1500);
                }
        }            
        if(!bankingnow && walkingnow && !fightingnow) //has shark , continue trip
        {        
              if(isAtApproxCoords(498,447,6)){
                   int[] bankGate=getObjectById(64);
                if(bankGate[0]!=-1)
                {
                    atObject(bankGate[1],bankGate[2]);  
                        return random(200,300);
                }
                else
                {
                    walkTo(500,454);      
                    return random(1000,1500);
                }
            }
            if(getX()>=500&&getX()<523)
            {
                walkTo(523,458);
                return random(1000,1500);
            }
            if(getX()>=523&&getX()<540 )
            {
                walkTo(540,473);
                return random(1000,1500);
            }
            if(getX()>=540&&getX()<548 )
            {
                walkTo(548,476);
                return random(1000,1500);
            }
            if(getX()>=548&&getX()<572 )
            {
                walkTo(572,476);    
                return random(1000,1500);
            }
            if(getX()>=572&&getX()<590 )
            {
                walkTo(590,461);
                return random(1000,1500);
            }
            if(getX()>=590&&getX()<592 )
            {
                walkTo(592,458);
                return random(1000,1500);
            }            
            if(isAtApproxCoords(592,458,2) &&getX()<=592)
            {
                int[] log = getObjectById(680);
                if(log[0]!=-1){
                    atObject(log[1],log[2]);
                   return random(500,600);
                }
                return random(500,600);
            }            
            if(getX()>=597&&getX()<608)
            {
                walkTo(608,465);
                return random(1000,1500);
            }
            if(getX()>=608&&getX()<617 )
            {
                walkTo(617,473);
                return random(1000,1500);
            }
            if(getX()==617&&getY()==473) // not past gate and gate closed, open it
            {
                int[] gate = getObjectById(57);
                if(gate[0]!=-1){
                    atObject(gate[1],gate[2]);
                    walkTo(617,474);
                   return random(2500,2600);
                }
                else
                {
                    walkTo(617,474);
                    return random(150,200);
                }
            }
            if(getX()>=617&&getX()<637 && getY()<3000)
            {
                walkTo(637,463);
                return random(1000,1500);
            }
            if(getX()>=637&&getX()<651 && getY()<3000)
            {
                walkTo(651,448);
                return random(1000,1500);
            }
            if(getX()>=651&&getX()<654 && getY()<3000)
            {
                walkTo(654,451);
                return random(1000,1500);
            }
            if(getX()>=654&&getX()<658 && getY()<3000)
            {
                walkTo(658,451);
                return random(1000,1500);
            }
            if(getX()>=658&&getX()<659 && getY()<3000)
            {
                walkTo(659,449);
                return random(600,900);
            }            
            if(getX()==659&&getY()==449 ) //  board boaty
            {
                int[] boat = getObjectById(464);
                    atObject(boat[1],boat[2]);
                   return random(2000,2500);
            }
            if(getX()==662&&getY()==463 ) //  use rope on  1st tree
            {                
                useItemOnObject(237,462);
                return random(5000,6500);
            }
            if(getX()==662&&getY()==467 ) //  use rope on 2nd tree
            {
                useItemOnObject(237,463);
                return random(5000,6500);
            }
            if(getX()==659&&getY()==471 ) //  use rope on 3rd tree
            {
                useItemOnObject(237,482);
                return random(5000,6500);
            }
            if(getX() == 659&&getX()<=3305 && getFatigue() > 0) //1st waterfall door
            {
                useSleepingBag();
                return 3000;
            } 
            if(getY()>3302&&getY()<=3305 && getFatigue() < 1) //1st waterfall door
            {
                int[] wooddoorc = getObjectById(471);
                if(wooddoorc[0]!=-1 ){
                    atObject(wooddoorc[1],wooddoorc[2]);
                   return random(500,600);
                }
            }            
            if(getY()>3295&&getY()<=3302)// walk to 2nd door
            {
                    walkTo(659,3295);
                    return random(150,200);
            }
            if(getX()==659&&getY()==3295)// 2nd chamber door
            {
                int[] wooddoord = getObjectById(64);
                if(wooddoord[0]!=-1){                    
                    atObject(wooddoord[1],wooddoord[2]);
                    walkTo(659,3294);
                   return random(1500,1600);
                }
                else
                {                    
                    walkTo(659,3294);
                    return random(150,200);
                }
            }
            if(getY()>3289&&getY()<=3294)// walk to 3rd oor
            {
                    walkTo(659,3289);
                    return random(300,400);
            }
            if(getX()==659f&&getY()==3289) // opening 3rd chamber door
            {
                int[] wooddoore = getObjectById(64);
                if(wooddoore[0]!=-1){
                    atObject(wooddoore[1],wooddoore[2]);
                    walkTo(659,3286);
                    wearItem(getInventoryIndex(597));                    
                    return random(500,600);
                }
                else
                {
                    walkTo(659,3286);
                    wearItem(getInventoryIndex(597));            
                    return random(150,200);
                }
            }
            if(getY()>3250&&getY()<=3288)// walk to 3rd oor
            {
                     bankingnow = false;
                     walkingnow = false;
                     fightingnow = true;
                    return random(300,400);
            }
        }

        if(!bankingnow && !walkingnow && fightingnow) { //fightingpart            
           if(isAtApproxCoords(456,456,2)) { 
                bankingnow = true;
                walkingnow = false;
                fightingnow = false;
           }

           int currentHitsDown = getLevel(3)-getCurrentLevel(3);

           // If our health is lower than 21 below our max
           if(currentHitsDown > 21) {
                // Emergency fkn YEET BOI
                // This should never really happen, but it was in the script before I started editing
                // so better safe than sorry.
                if(getCurrentLevel(3) <= 25 ) {
                    castOnSelf(22);
                    return 100;
                }

                // If we have food
                if ((getInventoryCount(373) > 0) || (getInventoryCount(546) > 0)) {
                    // If HP is lower than 50 and in combat, get out of it.
                    if ((inCombat()) && (getCurrentLevel(3) <= 50)) {
                        walkTo(getX(), getY());
                        return 640;
                    }

                    // If we have lobs, use them first.
                    // Then Shark
                    // Last resort, tele
                    if (!inCombat()) {
                        if (getInventoryCount(373) > 0) {
                            useItem(getInventoryIndex(373));
                            return random(900, 1200);
                        } else if (getInventoryCount(546) > 0) {
                            useItem(getInventoryIndex(546));
                            foodused  += 1;
                            return random(1200, 1500);
                        }
                    }
                }
            }

            // We're only going to run from combat if high value items pop up.
            // Otherwise we just wait for the combat to end
            for (int hvLoop : HIGH_VALUE_DROPS) {

                int[] ITEM_DROP = getItemById(hvLoop);
                if (ITEM_DROP[0] != -1) {
                    // If we're not ontop of the item or we're in combat, walk.
                    if (!isAtApproxCoords(ITEM_DROP[1], ITEM_DROP[2], 1) || inCombat()) {
                        walkTo(ITEM_DROP[1], ITEM_DROP[2]);
                        return 640;
                    }

                    // We gotta do something to clean out an inventory slot
                    if (getInventoryCount() == 30) {
                        if (getInventoryCount(413) > 0) {
                            useItem(getInventoryIndex(413));
                            return random(900, 1200);
                        } else if (getInventoryCount(373) > 0) {
                            useItem(getInventoryIndex(373));
                            return random(1200, 1500);
                        } else if (getInventoryCount(546) > 0) {
                            useItem(getInventoryIndex(546));
                            return random(1200, 1500);
                        }
                    }

                    // Finally, all good to pick up the item.
                    pickupItem(ITEM_DROP[0], ITEM_DROP[1], ITEM_DROP[2]);
                    return random(200,300);  
                }
            }

            if (!inCombat()) {
                int[] npc = getNpcInRadius(344, 656, 3280, 8);

                // We have no food, we're not in combat, and there's no high drops to pickup.
                if ((getInventoryCount(546) == 0) && (getInventoryCount(373) == 0)) {
                    // Check to see if there's an NPC around, and that they aren't under us.
                    // If they are under us it means we just ran to eat our last food and should continue combat
                    // until we finish them and get the drop.
                    if ((npc[0] == -1) || ((npc[0] != -1) && (npc[1] != getX()) && (npc[2] != getY()))) {
                        castOnSelf(22);
                        return 100;
                    }
                }

                ITEM_DROP = get_reachable_item(MEDIUM_VALUE_DROPS);
                if (ITEM_DROP[0] != -1) {
                    // If we're not ontop of the item and we're not in combat, walk.
                    if (!isAtApproxCoords(ITEM_DROP[1], ITEM_DROP[2], 1) && !inCombat()) {
                        walkTo(ITEM_DROP[1], ITEM_DROP[2]);
                        return 640;
                    }

                    // We gotta do something to clean out an inventory slot
                    if (getInventoryCount() == 30) {
                        if (getInventoryCount(413) > 0) {
                            useItem(getInventoryIndex(413));
                            return random(900, 1200);
                        } else if (getInventoryCount(373) > 0) {
                            useItem(getInventoryIndex(373));
                            return random(1200, 1500);
                        } else if (getInventoryCount(546) > 0) {
                            useItem(getInventoryIndex(546));
                            return random(1200, 1500);
                        }
                    }

                    // Finally, all good to pick up the item.
                    pickupItem(ITEM_DROP[0], ITEM_DROP[1], ITEM_DROP[2]);
                    return random(200,300);  
                }

                if ((getInventoryCount() != 30) || (getInventoryCount(413) > 0)) {
                    // Low value drops, only pickup if we have room and not in combat
                    ITEM_DROP = get_reachable_item(LOW_VALUE_DROPS);
                    if (ITEM_DROP[0] != -1) {
                        // If we're not ontop of the item or and we're not in combat, walk.
                        if (!isAtApproxCoords(ITEM_DROP[1], ITEM_DROP[2], 1) && !inCombat()) {
                            walkTo(ITEM_DROP[1], ITEM_DROP[2]);
                            return 640;
                        }

                        if (getInventoryCount() == 30) {
                            if (getInventoryCount(413) > 0) {
                                useItem(getInventoryIndex(413));
                                return random(900, 1200);
                            }
                        }
                        // Finally, all good to pick up the item.
                        pickupItem(ITEM_DROP[0], ITEM_DROP[1], ITEM_DROP[2]);
                        return random(200,300);  
                    }
                }

                if(getFatigue() > 55) {
                    useSleepingBag();
                    return 1000;
                }

                if(npc[0] != -1) {
                    attackNpc(npc[0]);
                    return random(900, 1100);
                }

                // If we have bones and there's nothing else to do, burry.
                if (getInventoryIndex(413) > 0) {
                    useItem(getInventoryIndex(413));
                    return random(900, 1200);
                }
            }

            // Might need to change this to ,9 instead of ,8
            if (!isAtApproxCoords(656, 3280, 8)) {
                walkTo(660, 3285);
                return random(900, 1100);
            }
        }
        return random(1200, 1500);
	}

	private int[] get_reachable_item(int... ids) {
		int[] item = new int[] {
			-1, -1, -1
		};
		int count = getGroundItemCount();
		int max_dist = Integer.MAX_VALUE;
		for (int i = 0; i < count; i++) {
			int id = getGroundItemId(i);
			if (inArray(ids, id)) {
				int x = getItemX(i);
				int y = getItemY(i);
				if (!isReachable(x, y)) continue;
				int dist = distanceTo(x, y, getX(), getY());
				if (dist < max_dist) {
					item[0] = id;
					item[1] = x;
					item[2] = y;
					max_dist = dist;
				}
			}
		}
		return item;
	}

    @Override
    public void onServerMessage(String str) {
        str = str.toLowerCase(Locale.ENGLISH);
        if (str.contains("bury")) {
            ++bonesburied;
        } else if (str.contains("secret")) {
            ++trips;
	    }
    }
    public void paint() {
        int y = 40;
        int x = 315;
        y += 15;
        drawString("@whi@Obtained@red@ " + dsq + " @whi@Left Halves.", x, y, 1, 0xFFA600);
        y += 15;
        drawString("@whi@Obtained@red@ " + dmed + " @whi@Dragon mediums.", x, y, 1, 0xFFA600);
        y += 15;
        drawString("@whi@Obtained@red@ " + rscim + " @whi@Rune Scims.", x, y, 1, 0xFFA600);
        y += 15;
        drawString("@whi@Obtained@red@ " + r2h + " @whi@R2hs.", x, y, 1, 0xFFA600);
        y += 15;
        drawString("@whi@Obtained@red@ " + rkite + " @whi@Rune kites.", x, y, 1, 0xFFA600);
        y += 15;
        drawString("@whi@Obtained@red@ " + rbaxe + " @whi@Rune Battleaxe's.", x, y, 1, 0xFFA600);
        y += 15;
        drawString("@whi@Obtained@red@ " + rspear + " @whi@Rune Spears.", x, y, 1, 0xFFA600);
        y += 15;
        drawString("@whi@Obtained@red@ " + loop + " @whi@Half Key (loop).", x, y, 1, 0xFFA600);
        y += 15;
        drawString("@whi@Obtained@red@ " + teeth + " @whi@Half Key (teeth).", x, y, 1, 0xFFA600);
        y += 15;
        drawString("@whi@Obtained@red@ " + firebstf + " @whi@Battlestaffs.", x, y, 1, 0xFFA600);
        y += 15;
        drawString("@whi@Obtained@red@ " + blood + " @whi@Bloods.", x, y, 1, 0xFFA600);
        y += 15;
        drawString("@whi@Obtained@red@ " + fire + " @whi@Fires.", x, y, 1, 0xFFA600);
        int ab = 12;
        int cd = 50;
        drawString("@or3@Fire Giant Killer@whi@", ab-4, cd-17, 4, 0xFFFFFF);
        drawString("@whi@Food Used: @red@" + foodused + "@whi@ ", ab, cd, 1, 0xFFFFFF);
        cd += 15;
        drawString("@whi@Trip Number:@red@ " + trips + "@whi@ ", ab, cd, 1, 0xFFFFFF);
        cd += 15;
        drawString("@whi@Buried:@red@ " + bonesburied + "@whi@ Bones (@red@" + 
                (bonesburied * 12.5D) + "@whi@ xp)", ab, cd, 1, 0xFFFFFF);
        cd += 15;
        drawString("@whi@Runtime: " + getTimeRunning(), ab, cd, 1, 0xFFFFFF);
        drawVLine(8, 37, cd + 3 - 37, 0xFFFFFF);
        drawHLine(8, cd + 3, 183, 0xFFFFFF);
    }    
    private String perHour(int i) {
        int ph;
        try {
            ph = (int)(((i * 60L) * 60L) / ((System.currentTimeMillis() - this.time) / 1000L));
        } catch(ArithmeticException e) {
            return "(waiting...)";
        }
        return "(" + ph + "/h)";
    }    
    private String getTimeRunning() {
        long time = ((System.currentTimeMillis() - this.time) / 1000);
        if (time >= 7200) {
            return new String((time / 3600) + " hours, " + ((time % 3600) / 60) + " minutes, " + (time % 60) + " seconds.");
        }
        if (time >= 3600 && time < 7200) {
            return new String((time / 3600) + " hour, " + ((time % 3600) / 60) + " minutes, " + (time % 60) + " seconds.");
        }
        if (time >= 60) {
            return new String(time / 60 + " minutes, " + (time % 60) + " seconds.");
        }
        return new String(time + " seconds.");
    }
    int stat;
    long time = -1L;
    private String doCase(String str) {
        return new String(str.substring(0, 1).toUpperCase() + str.substring(1, str.length()));
    }
}