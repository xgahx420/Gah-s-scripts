import javax.swing.JOptionPane;

public class wildybar_Fatigue extends Script {

   long time = 0;
   int[] skillArea = new int[]{74, 437};
   int[] fightArea = new int[]{81, 446};
   int npcId = 64;
   int killXp = 64;
   int eatAtHp = 30;
   int fightMode;
   int kills;
   int totalxp;
   private boolean init;
   boolean fighting = false;
   boolean walkBack = false;

   public wildybar_Fatigue (Extension e) {
    super(e);
   }
   
   public void init(String params) {
       Object[] option1 = {"Lobster", "Swordfish", "Shark"};
       String foodType = (String)JOptionPane.showInputDialog(null, "Food type?", "JailGuard Fatigue", JOptionPane.PLAIN_MESSAGE, null, option1, option1[0]);
       Object[] option2 = {"Attack", "Strength", "Defense", "Controlled"};
       String fightM = (String)JOptionPane.showInputDialog(null, "Fightmode?", "JailGuard Fatigue", JOptionPane.PLAIN_MESSAGE, null, option2, option2[0]);

       if(foodType.equals("Lobster")) {
           food = 373;
       } else
       if(foodType.equals("Swordfish")) {
           food = 370;
       } else
       if(foodType.equals("Shark")) {
           food = 546;
       }
       
       if(fightM.equals("Controlled")) {
           fightMode = 0;
       } else
       if(fightM.equals("Strength")) {
           fightMode = 1;
       } else
       if(fightM.equals("Attack")) {
           fightMode = 2;
       } else
       if(fightM.equals("Defense")) {
           fightMode = 3;
       }
   }  

   public int main() {

   setTrickMode(true);

   if(getFightMode() != fightMode) {
    setFightMode(fightMode);
    return 100;
   }

   if (!init) {
    time = System.currentTimeMillis();
    init = true;
   }

   if(walkBack) {
    if(!isAtApproxCoords(skillArea[0], skillArea[1], 4)) {
    walkTo(skillArea[0], skillArea[1]);
    return random(500, 650);
    } else {
    walkBack = false;
    }
   }

   if(getFatigue() == 100) {
    if(fighting) {
    kills += 1;
    totalxp += killXp;
    fighting = false;
    }
    if(isTricking()) {
    useSleepingBag();
    return 1000;
    } else {
    setTrickMode(true);
    return 1000;
    }
   }

   if(getFatigue() < 99) {
    if(!isAtApproxCoords(skillArea[0], skillArea[1], 10)) {
    walkBack = true;
    }

    if(hasInventoryItem(food) && getCurrentLevel(3) <= eatAtHp && !inCombat()) {
    useItem(getInventoryIndex(food));
    return random(1100, 1500);
 	}
        if (getFatigue() == 100) {
            useSleepingBag();
            return random(1000, 1500);

    }

    int[] log = getItemById(14);
    if(log[0] != -1 && !isObjectAt(log[1], log[2]) && log[1] == getX() && log[2] == getY() && getFatigue() <= 95 && !inCombat()) {
    int tinder = getInventoryIndex(166);
    useItemOnGroundItem(tinder, log[0], log[1], log[2]);
    return random(750, 1000);
    } else {
    int[] tree = getObjectById(new int[]{0, 1});
    atObject(tree[1], tree[2]);
    return random(750, 1000);
    }
   }

   if(getFatigue() == 99) {
    if(!fighting) {
    fighting = true;
    }
    if(!isAtApproxCoords(fightArea[0], fightArea[1], 10) && !inCombat()) {
    walkTo(fightArea[0], fightArea[1]);
    return random(600, 900);
    }

    if(isAtApproxCoords(fightArea[0], fightArea[1], 10)) {
    int[] npc;
    npc = getNpcInRadius(npcId, fightArea[0], fightArea[1], 10);

    if(npc[0] != -1 && !inCombat()) {
    attackNpc(npc[0]);
    return random(750, 1000);
    }

    if(npc[0] == -1 && !inCombat() && !isAtApproxCoords(fightArea[0], fightArea[1], 0)) {
    walkTo(fightArea[0], fightArea[1]);
    return random(750, 1000);
    }
    }
   }
       return 1000;
   }

   public void paint() {
    int y = 215;
    int x = 10;
    drawString("Combat XP: " + ""+totalxp+"", x, y, 1, 0xDE62CF);
    y += 15;
    drawString("Kills: " + ""+kills+"", x, y, 1, 0xDE62CF);
    y += 15;
       drawString("XP/H: " + getXpH(), x, y, 1, 0xE01E1B);
    y += 15;
       drawString("Running for " + getTimeRunning(), x, y, 1, 0xE01E1B);
   }

   private String getTimeRunning() {
       long l = ((System.currentTimeMillis() - time) / 1000);
       if (l >= 7200) {
           return new String((l / 3600) + " hour(s), " + ((l % 3600) / 60) + " minute(s), " + (l % 60) + " second(s).");
       }
       if (l >= 3600 && l < 7200) {
           return new String((l / 3600) + " hour(s), " + ((l % 3600) / 60) + " minute(s), " + (l % 60) + " second(s).");
       }
       if (l >= 60) {
           return new String(l / 60 + " minute(s), " + (l % 60) + " second(s).");
       }
       return new String(l + " second(s).");
   }

   private long getXpH() {
       try {
    long xph = (((totalxp) * 60) * 60) / (((System.currentTimeMillis() - time) / 1000));
    return xph;
       } catch(ArithmeticException e) {}
       return 0;
   }

       private int food;
}