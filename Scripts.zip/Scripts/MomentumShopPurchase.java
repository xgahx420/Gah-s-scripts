import java.util.Locale;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Choice;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;
import java.util.*;
import java.util.ArrayList;
import java.net.*;
import java.io.*;
import com.aposbot.Constants;
import com.aposbot.StandardCloseHandler;
import static java.lang.System.currentTimeMillis;

public final class MomentumShopPurchase extends Script
        implements ActionListener {

private static final int AUBURY = 54;
private Frame frame;
private boolean init;
private int[] npcList = {};
private int shopNpcId;
private int shopAnswer;
private int[] item_ids;
private int maxGP;
private Choice ch_npcs;
private Choice ch_answer;
private TextField tf_items;
private TextField tf_max_gp;
private int starting_gp;
private int stage     = 0;
private long startTime;
private long lastBuy;
private ArrayList<Integer> itemcount = new ArrayList<>();
private ArrayList<Integer> startitemcount = new ArrayList<>();
private long lastInShop;

public MomentumShopPurchase (Extension e) {
        super(e);
}

public static void main(String[] argv) {
        new MomentumShopPurchase(null).init(null);
}

@Override
public void init(String params){
        init = false;
        if (frame == null) {
                ch_npcs = new Choice();
                int npcCount = countNpcs();
                for (int n = 0; n < npcCount -1; n++) {
                        int npcId = getNpcId(n);
                        String npcName = getNpcName(n);
                        ch_npcs.add(npcName);
                        if (npcList.length > 0) {
                                npcList = addToArray(npcList,npcId);
                        } else {
                                npcList = new int[] {npcId};
                        }
                }
                ch_answer = new Choice();
                ch_answer.add("1st Menu Response");
                ch_answer.add("2nd Menu Response");
                ch_answer.add("3rd Menu Response");
                ch_answer.add("4th Menu Response");

                Panel pInput = new Panel();
                pInput.setLayout(new GridLayout(0,2,0,2));
                pInput.add(new Label("Which NPC?"));
                pInput.add(ch_npcs);
                pInput.add(new Label("Which menu response opens the shop?"));
                pInput.add(ch_answer);
                pInput.add(new Label("Item's to buy? (1,2,3..)"));
                pInput.add(tf_items = new TextField());
                pInput.add(new Label("Max GP to spend?"));
                pInput.add(tf_max_gp = new TextField("0"));

                Panel buttonPanel = new Panel();
                Button ok = new Button("OK");
                ok.addActionListener(this);
                buttonPanel.add(ok);
                Button cancel = new Button("Cancel");
                cancel.addActionListener(this);
                buttonPanel.add(cancel);
                frame = new Frame(getClass().getSimpleName());
                frame.setIconImages(Constants.ICONS);
                frame.addWindowListener(
                        new StandardCloseHandler(frame, StandardCloseHandler.HIDE)
                        );
                frame.add(pInput, BorderLayout.NORTH);
                frame.add(buttonPanel, BorderLayout.SOUTH);
                frame.setResizable(false);
                frame.pack();
        }
        frame.setLocationRelativeTo(null);
        frame.toFront();
        frame.requestFocus();
        frame.setVisible(true);
        for (int ii =0; ii <= 1289; ii++){
          itemcount.add(0);
          startitemcount.add(0);
        }
        startTime = currentTimeMillis();
        lastInShop = currentTimeMillis();
        lastBuy = currentTimeMillis();
}



@Override
public int main()
{
        if (stage == 0) {
                starting_gp = getInventoryCount(10);
                for(int buyItem = 0; buyItem < item_ids.length; buyItem++)
                        {
                               startitemcount.set(item_ids[buyItem], getInventoryCount(item_ids[buyItem]));
                        }
                stage = 1;
        }
        if (maxGP > 0) {
                if ((starting_gp - getInventoryCount(10)) > maxGP ) {
                        System.out.println("Stopping Script. Over max GP spent: " + (starting_gp - getInventoryCount(10)));
                        stopScript();
                }
        }
        long buyTimeNow = currentTimeMillis();
        long noBuy = (buyTimeNow - lastBuy) / 1000;
        if (noBuy >= 400){
          if (isShopOpen()){
            closeShop();
            stage = 1;
            lastBuy = currentTimeMillis() - (250 * 1000);
          }
        }

        if(stage == 1) {
                if (isShopOpen()){
                stage = 3;
                return random(200,500);
                }

                //System.out.println("stage_1");
                if (!isShopOpen() && !isQuestMenu()) {
                        int[] shopNPC = getNpcById(shopNpcId);
                        talkToNpc(shopNPC[0]);
                        return random(1000, 2000);
                }

                if (isQuestMenu()) {
                        stage++;
                        return random(2000,3000);
                }
                if (!isQuestMenu() && !isShopOpen()){
                  long timeNow = currentTimeMillis();
                  long outOfShop = (timeNow - lastInShop);
                  if ((outOfShop / 1000) > 200){
                    stage = 1;
                  }
                }
                return random(3000,4000);

        }

        if(stage == 2)
        {
                if (isQuestMenu() && !isShopOpen()) {
                        //System.out.println("stage_2");
                        answer(shopAnswer);
                        return random(2500, 4000);
                }
                if (isShopOpen()) {
                        stage = 3;
                        return random(1000,2000);
                }
                if (!isQuestMenu() && !isShopOpen()){
                  long timeNow = currentTimeMillis();
                  long outOfShop = (timeNow - lastInShop);
                  if ((outOfShop / 1000) > 60){
                    stage = 1;
                  }
                }
                return random(1000,2000);
        }

        if(stage == 3) {
                //System.out.println("stage_3");
                //System.out.println("stage_3.1");
                if (isShopOpen()) {
                        lastInShop = currentTimeMillis();
                        for(int buyItem = 0; buyItem < item_ids.length; buyItem++)
                        {
                                int shopItem  = getShopItemById(item_ids[buyItem]);
                                int itemCount = getShopItemAmount(shopItem);

                               itemcount.set(item_ids[buyItem], getInventoryCount(item_ids[buyItem]));

                                if (itemCount < 1)
                                {
                                        continue;
                                }
                                lastBuy = currentTimeMillis();
                                buyShopItem(shopItem, itemCount);
                                return random(400,500);
                        }
                } else {
                        stage = 1;
                }
                return random(1000,2000);

                //System.out.println("stage_3.2");
        }



        if(stage == 4) {
                //System.out.println("stage_4");
                stage = 1;
                return random(1500, 2000);
        }

        if (!isQuestMenu() && !isShopOpen()){
          long timeNow = currentTimeMillis();
          long outOfShop = (timeNow - lastInShop);
          if ((outOfShop / 1000) > 60){
            stage = 1;
          }
        }

        return random(2000, 3000);
}

@Override
public void onServerMessage(String str) {
        str = str.toLowerCase(Locale.ENGLISH);

        if (str.contains("Welcome")) {
                stage = 1;
        }
}

public int[] addToArray(int[] srcArray, int elementToAdd) {
        int[] destArray = new int[srcArray.length+1];

        for(int i = 0; i < srcArray.length; i++) {
                destArray[i] = srcArray[i];
        }

        destArray[destArray.length - 1] = elementToAdd;
        return destArray;
}

@Override
public void paint() {
        long time = currentTimeMillis();
        float timeDiff = (float)(time - startTime);
        final int white = 0xFFFFFF;
        int y = 140;
        drawString("Momentum Universal Shop Buyer", 300, y, 1, 0x005D7B);
        y += 15;
        int spentGP = (starting_gp - getInventoryCount(10));
        int gpPerHr = (int)Math.round(((float)spentGP / (timeDiff / 1000)) * 60 * 60);
        drawString("Spent Coins: " + spentGP + " (" + gpPerHr + " /hr)", 300, y, 1, 0xFFA600);
        y += 15;
        if (itemcount.size() > 0) {
                int num = itemcount.size();

                for (int i = 0; i < num; i++ ) {

                        if ((itemcount.get(i) - startitemcount.get(i)) <= 0) {
                                continue;
                        }
                        int purchased = (itemcount.get(i) - startitemcount.get(i));
                        int purchPerHour = (int)Math.round(((float)purchased / (timeDiff / 1000)) * 60 * 60);
                        drawString("Purchased " + getItemNameId(i) + ": " + purchased + " (" + purchPerHour + " /hr)", 300, y, 1, 0xFFA600);
                        y += 15;
                }
        }

}

@Override
public void actionPerformed(ActionEvent event) {
        if (event.getActionCommand().equals("OK")) {
                try {
                        shopNpcId = npcList[ch_npcs.getSelectedIndex()];
                } catch (Throwable t) {
                        System.out.println("Error setting NPC id");
                        shopNpcId = 0;
                }
                try {
                        shopAnswer = ch_answer.getSelectedIndex();
                } catch (Throwable t) {
                        System.out.println("Error with shop answer");
                        shopAnswer = 0;
                }
                try {
                        String[] array = tf_items.getText().trim().split(",");
                        int array_sz = array.length;
                        item_ids = new int[array_sz];
                        for (int i = 0; i < array_sz; i++) {
                                item_ids[i] = Integer.parseInt(array[i]);
                        }
                } catch (Throwable t) {
                        System.out.println("Couldn't parse item ids");
                        item_ids = new int[0];
                }
                try {
                        maxGP = Integer.parseInt(tf_max_gp.getText().trim());
                } catch (Throwable t) {
                        System.out.println("Couldn't parse max GP");
                }
        }
        frame.setVisible(false);
}
}
