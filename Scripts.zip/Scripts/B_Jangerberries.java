public class B_Jangerberries extends Script {

  private final int[][] JANGERBERRIES = {{936, 663, 755}, {936, 658, 757}, {936, 658, 760}};
  private final int SLEEPING_BAG = 1263;
  private final int STAFF_OF_AIR = 101;
  private final int LAW_RUNE = 42;
  private final int BANK_X = 586;
  private final int BANK_Y = 753;
  private final int ISLE_X = 654;
  private final int ISLE_Y = 754;
  private PathWalker pw;
  private PathWalker.Path to_bank;
  private PathWalker.Path to_isle;
  private int berries;
  private int started;
  private long time;
  private boolean collected;

  public B_Jangerberries(Extension e) {
      super(e);
      this.pw = new PathWalker(e);
  }

  @Override
  public void init(String s) {
      pw.init(null);
      to_bank = pw.calcPath(ISLE_X, ISLE_Y, BANK_X, BANK_Y);
      to_isle = pw.calcPath(BANK_X, BANK_Y, ISLE_X, ISLE_Y);
      berries = 0;
      started = 0;
      time = -1L;
      collected = false;
  }

  @Override
  public int main() {
      if (started < 1) {
          started = getXpForLevel(3);
          time = System.currentTimeMillis();
      }
      if (inCombat()) {
          walkTo(getX(), getY());
          return random(400, 600);
      }
      if (getFatigue() > 95) {
          useSleepingBag();
          return random(800, 1200);
      }
      if (isBanking()) {
          int sleeping_bag = getInventoryCount(SLEEPING_BAG);
          if (sleeping_bag < 1) {
              withdraw(SLEEPING_BAG, 1);
              return random(800, 1200);
          }
          int staff = getInventoryCount(STAFF_OF_AIR);
          if (staff < 1) {
              withdraw(STAFF_OF_AIR, 1);
              return random(800, 1200);
          }
          int berries = getInventoryCount(JANGERBERRIES[0][0]);
          if (berries > 0) {
              deposit(JANGERBERRIES[0][0], berries);
              return random(800, 1200);
          }
          int laws = getInventoryCount(LAW_RUNE);
          if (laws < 28) {
              withdraw(LAW_RUNE, 28 - laws);
              return random(800, 1200);
          }
          pw.setPath(to_isle);
          closeBank();
          return random(800, 1200);
      }
      if (hasInventoryItem(STAFF_OF_AIR) && hasInventoryItem(LAW_RUNE) && getEmptySlots() > 0) {
          int staff = getInventoryIndex(STAFF_OF_AIR);
          if (!isItemEquipped(staff)) {
              wearItem(staff);
              return random(800, 1200);
          }
          pw.setPath(to_isle);
          if (isAtApproxCoords(ISLE_X, ISLE_Y, 10)) {
              for (int[] jangerberry : JANGERBERRIES) {
                  if (getItemIdFromCoords(jangerberry[1], jangerberry[2]) != -1) {
                      if (jangerberry[2] == 755 && !isAtApproxCoords(659, 751, 1)) {
                          walkTo(659, 751);
                          return random(1200, 1400);
                      }
                      if ((jangerberry[2] == 757 || jangerberry[2] == 760) && !isAtApproxCoords(654, 757, 1)) {
                          walkTo(654, 757);
                          return random(1200, 1400);
                      }
                      collected = true;
                      castOnGroundItem(16, jangerberry[0], jangerberry[1], jangerberry[2]);
                      return random(2000, 3000);
                  }
              }
          }
          if (collected) {
              collected = false;
              autohop(false);
              return random(800, 1200);
          }
          if (isAtApproxCoords(ISLE_X, ISLE_Y, 10)) {
              return random(800, 1200);
          }
      } else {
          if (isAtApproxCoords(ISLE_X, ISLE_Y, 10)) {
              pw.setPath(to_bank);
          }
      }
      if (pw.walkPath()) {
          return random(800, 1200);
      }
      if (isQuestMenu()) {
          answer(0);
          return 5000;
      }
      int[] bankers = getNpcByIdNotTalk(BANKERS);
      if (bankers[0] != -1) {
          talkToNpc(bankers[0]);
          return 5000;
      }
      return random(800, 1200);
  }

  public int getItemIdFromCoords(int paramInt1, int paramInt2) {
      for (int i = 0; i < getGroundItemCount(); i++) {
          if ((getItemX(i) == paramInt1) && (getItemY(i) == paramInt2)) {
              return getGroundItemId(i);
          }
      }
      return -1;
  }

  private int perHour(int total) {
      long time = ((System.currentTimeMillis() - this.time) / 1000L);
      if (time < 1L) {
          time = 1L;
      }
      return ((int) ((total * 60L * 60L) / time));
  }

  private String getRunTime() {
      long millis = (System.currentTimeMillis() - time) / 1000;
      long second = millis % 60;
      long minute = (millis / 60) % 60;
      long hour = (millis / (60 * 60)) % 24;
      long day = (millis / (60 * 60 * 24));

      if (day > 0L) return String.format("%02d days, %02d hrs, %02d mins", day, hour, minute, second);
      if (hour > 0L) return String.format("%02d hours, %02d mins, %02d secs", hour, minute, second);
      if (minute > 0L) return String.format("%02d minutes, %02d seconds", minute, second);
      return String.format("%02d seconds", second);
  }

  @Override
  public void paint() {
      int x = 12;
      int y = 50;
      drawString("Blood's Jangerberries", x - 4, y - 17, 4, 0x00b500);
      drawString("Collected " + berries + " berries (" + perHour(berries) + "/h)", x, y, 1, 0xFFFFFF);
      y += 15;
      drawString("Runtime: " + getRunTime(), x, y, 1, 0xFFFFFF);
      drawVLine(8, 37, y + 3 - 37, 0xFFFFFF);
      drawHLine(8, y + 3, 183, 0xFFFFFF);
  }

  @Override
  public void onServerMessage(String s) {
      if (s.contains("Spell successful")) {
          berries++;
          return;
      }
  }
}