import java.awt.Point;

/**
* Guard dogs fatigue script for McGrubor's Wood
* Start with gdfatigue fmodeid,foodid,foodam,eatat
*
* @author Storm
*/
public class WILDBARFatigue extends Script {

    // fatigue to stop lighting fires and just cut at, adjust if you like
    private final int limit = 97;

    private int cs;
    private int foodid;
    private int foodam;
    private int eatat;

    private final Point[] path = { new Point(80, 445), new Point(80, 436), new Point(74, 438), new Point(74, 438) };
    private int pindex;

    private int startxp;
    private long time;
    private boolean init;

    public WILDBARFatigue(Extension ex) {
        super(ex);
    }

    public void init(String args) {
        setTrickMode(true);
        String[] array = args.split(",");
        cs = Integer.parseInt(array[0]);
        foodid = Integer.parseInt(array[1]);
        foodam = Integer.parseInt(array[2]);
        eatat = Integer.parseInt(array[3]);
        pindex = 0;
        init = false;
    }

    public int main() {
        if (!init) {
            switch (cs) {
                case 0:
                    startxp = (getXpForLevel(0) + getXpForLevel(1) + getXpForLevel(2));
                    break;
                case 1:
                    startxp = getXpForLevel(2);
                    break;
                case 2:
                    startxp = getXpForLevel(0);
                    break;
                case 3:
                    startxp = getXpForLevel(1);
                    break;
            }
            time = System.currentTimeMillis();
            init = true;
        }
        if (isQuestMenu()) {
            answer(0);
            return random(4500, 4700);
        }
        if (isBanking()) {
            int amount = getInventoryCount(14);
            if (amount > 0) {
                deposit(14, amount);
                return random(600, 800);
            }
            if (!hasInventoryItem(foodid)) {
                if (hasBankItem(foodid)) {
                    withdraw(foodid, foodam);
                    return random(600, 800);
                }
                writeLine("Out of food!");
                stopScript();
                AutoLogin.setAutoLogin(false);
                logout();
                return 0;
            }
            closeBank();
            return random(1000, 1300);
        }
        if (inCombat()) {
            if (getFightMode() != cs) {
                setFightMode(cs);
            }
            return random(200, 300);
        }
        if (getFatigue() == 100) {
            useSleepingBag();
            return random(1000, 1500);
        }
        if (getX() > 539) {
            if (getCurrentLevel(3) <= eatat) {
                int index = getInventoryIndex(foodid);
                if (index != -1) {
                    useItem(index);
                    return random(600, 800);
                }
                int[] fence = getWallObjectById(101);
                if (fence[0] != -1 && distanceTo(fence[1], fence[2]) < 4) {
                    atWallObject(fence[1], fence[2]);
                    return random(1000, 1500);
                }
                if (isWalking())
                    return 0;
                if (getX() > 562) {
                    walkTo(562, 459);
                    return random(1000, 1500);
                }
                if (getX() > 550) {
                    walkTo(74 - random(0, 2), 459 - random(0, 2));
                    return random(1000, 1500);
                }
                walkTo(80, 446 - random(0, 2));
                return random(1000, 1500);
            }
            if (getFatigue() == 99) {
                int[] Thief = getNpcById(64);
                if (Thief[0] != -1) {
                    if (distanceTo(Thief[1], Thief[2]) > 4) {
                        if (isWalking())
                            return 0;
                        walkTo(Thief[1], Thief[2]);
                        return random(1000, 1500);
                    }
                    attackNpc(Thief[0]);
                    return random(600, 800);
                }
                return random(200, 300);
            }
            if (getFatigue() <= 98) {
                if (isSkilling())
                    return 0;
                if (!isObjectAt(getX(), getY()) && isItemAt(14, getX(), getY()) && getFatigue() < limit) {
                    useItemOnGroundItem(getInventoryIndex(166), 14, getX(), getY());
                    return random(800, 1200);
                }
                int[] tree = getObjectById(1, 0);
                if (tree[0] != -1) {
                    if (inBounds(tree[1], tree[2])) {
                        atObject(tree[1], tree[2]);
                        return random(1000, 1500);
                    }
                    if (isWalking())
                        return 0;
                    walkTo(74, 438);
                    return random(1000, 1500);
                }
                return random(200, 300);
            }
            return random(200, 300);
        }
        if (isWalking())
            return random(83, 435);
        if (hasInventoryItem(foodid)) {
            if (getX() == 999 && getY() == 445) {
                int[] fence = getWallObjectById(101);
                if (fence[0] != -1) {
                    pindex = 0;
                    atWallObject(fence[1], fence[2]);
                    return random(1000, 1500);
                }
                return random(200, 300);
            }
            if (getY() < 454) {
                int[] door = getObjectById(64);
                if (door[0] != -1) {
                    atObject(door[1], door[2]);
                    return random(1000, 1500);
                }
            }
            walkPath(false);
            return random(1000, 1500);
        }
        if (getY() > 453) {
            int[] door = getObjectById(64);
            if (door[0] != -1) {
                atObject(door[1], door[2]);
                return random(1000, 1500);
            }
        }
        int[] banker = getNpcByIdNotTalk(95);
        if (banker[0] != -1 && distanceTo(banker[1], banker[2]) < 4) {
            talkToNpc(banker[0]);
            return random(2500, 2700);
        }
        walkPath(true);
        return random(1000, 1500);
    }

    private boolean inBounds(int x, int y) {
        if (y > 472)
            return false;
        if (y < 455)
            return false;
        if (x > 580)
            return false;
        if (x < 542)
            return false;
        return true;        
    }

    private void walkPath(boolean rev) {
        if (getPathX(rev) == getX() && getPathY(rev) == getY())
            pindex++;
        walkTo(getPathX(rev), getPathY(rev));
    }

    private int getPathX(boolean rev) {
        return (int) path[(rev ? ((path.length - 1) - pindex) : pindex)].getX();
    }

    private int getPathY(boolean rev) {
        return (int) path[(rev ? ((path.length - 1) - pindex) : pindex)].getY();
    }

    public void paint() {
        int y = 40;
        int x = 315;
        drawBoxAlphaFill(315, y, 185, 65, 160, 0x000000);
        drawBoxOutline(315, y, 185, 65, 0xF21DCB);
        y += 15;
        x += 3;
        drawString("~ilu 5eva <3~", x, y, 4, 0xF21DCB);
        y += 10;
        drawHLine(x - 2, y, 183, 0xF21DCB);
        y += 20;
        drawString("Running for " + getTimeRunning(), x, y, 1, 0xF21DCB);
        y += 15;
        drawString(FIGHTMODES[cs] + " xp: " + getXPGained(), x, y, 1, 0xF21DCB);
    }

    private int getXPGained() {
        int i = 0;
        switch (cs) {
            case 0:
                i = (getXpForLevel(0) + getXpForLevel(1) + getXpForLevel(2));
                break;
            case 1:
                i = getXpForLevel(2);
                break;
            case 2:
                i = getXpForLevel(0);
                break;
            case 3:
                i = getXpForLevel(1);
                break;
        }
        return (i - startxp);
    }

    private String getTimeRunning() {
        long l = ((System.currentTimeMillis() - time) / 1000);
        if (l > 3600) {
            return new String(l / 3600 + " hours.");
        }
        if (l > 60) {
            return new String(l / 60 + " minutes.");
        }
        return new String(l + " seconds.");
    }
}