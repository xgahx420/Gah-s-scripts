public class IbanDoll extends Script {
 
  public IbanDoll(Extension e) {
     super(e);
  }
 
  public void init(String params) {
	        return;
  }

  public int main() {
        return 2000;	 
  }
  
  public void onKeyPress(int K) {
useItemOnObject(1004, 913);
System.out.println("Using Doll on Pit");
    }  
}