import com.aposbot.Constants;

import java.awt.Font;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class AA_ShantayTrader extends AA_Script {
	private static final Coordinate COORDINATE_BANK_CHEST = new Coordinate(58, 731);

	private static final long MAX_TRADE_DURATION = 3000L;

	private static final int MAX_TRADE_SIZE = 12;
	private static final int TOTAL_TRADE_SIZE = MAX_TRADE_SIZE * 2;

	private int[] itemIds;
	private String rsn = "";
	private Instant startTime;

	private long tradeTimeout;
	private long tradeRequestTimeout;
	private long tradeOfferTimeout;

	private long bankTimeout;
	private long bankOpenTimeout;
	private long bankCloseTimeout;

	private int itemId;
	private int itemIdIndex;
	private int itemsTraded;
	private int itemsRemaining;

	private int previousPlayerY;

	private boolean receiver;
	private boolean idle;

	private boolean waitingForBank;
	private boolean tradeAcceptSent;
	private boolean tradeConfirmSent;

	public AA_ShantayTrader(final Extension extension) {
		super(extension);
	}

	@Override
	public void init(final String parameters) {
		if (!parameters.isEmpty()) {
			List<Integer> ids = null;

			final String[] args = parameters.split(" ");

			for (int i = 0; i < args.length; i++) {
				switch (args[i].toLowerCase()) {
					case "-i":
					case "--itemid":
						if (ids == null) {
							ids = new ArrayList<>();
						}

						ids.add(Integer.parseInt(args[++i]));
						break;
					case "-r":
					case "--rsn":
						this.rsn = args[++i].replace('_', ' ');
						break;
					default:
						throw new IllegalArgumentException("Error: malformed parameters. Try again ...");
				}
			}

			if (ids != null) {
				this.itemIds = ids.stream().mapToInt(i -> i).toArray();
				this.itemId = this.itemIds[this.itemIdIndex];
			}
		}

		if ((this.itemIds != null && this.rsn.isEmpty()) || (!this.rsn.isEmpty() && this.itemIds == null)) {
			throw new IllegalArgumentException("Must specify both rsn AND itemId(s).");
		}

		if (!this.rsn.isEmpty()) {
			final int[] player = this.getPlayerByName(this.rsn);

			if (player[0] != -1) {
				final int myPid = this.extension.getMobServerIndex(this.extension.getPlayer());
				final int theirPid = this.getPlayerPID(player[0]);

				if (myPid > theirPid) {
					throw new IllegalStateException(
						String.format("You must have a lower pid (%d) than %s (%d)!", myPid, this.rsn, theirPid)
					);
				}
			}
		} else {
			this.receiver = true;
		}

		this.startTime = Instant.now();
	}

	@Override
	public int main() {
		if (this.receiver) {
			return this.getInventoryCount() == TOTAL_TRADE_SIZE || this.isBanking() ? this.bank() : this.trade();
		}

		return this.getInventoryCount() == 0 || this.isBanking() ? this.bank() : this.trade();
	}

	@Override
	public void onServerMessage(final String message) {
		if (message.startsWith("declined", 17)) {
			this.reset();
		} else if (message.endsWith("successfully")) {
			this.itemsTraded += MAX_TRADE_SIZE;
			this.itemsRemaining -= MAX_TRADE_SIZE;
			this.reset();
		} else if (message.endsWith("men.") || message.endsWith("you.")) {
			this.bankOpenTimeout = System.currentTimeMillis() + TIMEOUT_FIVE_SECONDS;
		} else if (message.endsWith("area")) {
			this.idle = true;
			this.previousPlayerY = this.getY();
		}
	}

	@Override
	public void paint() {
		int y = PAINT_OFFSET_Y;

		this.drawString("@yel@Shantay Trader", PAINT_OFFSET_X, y, Font.BOLD, PAINT_COLOR);

		if (this.startTime == null) {
			return;
		}

		final long secondsElapsed = Duration.between(this.startTime, Instant.now()).getSeconds();

		this.drawString(String.format("@yel@Runtime: @whi@%s", getElapsedSeconds(secondsElapsed)),
			PAINT_OFFSET_X, y += PAINT_OFFSET_Y_INCREMENT, Font.BOLD, PAINT_COLOR);

		this.drawString("", PAINT_OFFSET_X, y += PAINT_OFFSET_Y_INCREMENT, Font.BOLD, PAINT_COLOR);

		this.drawString(String.format("@yel@Role: @gr1@%s", this.receiver ? "Receiver" : "Trader"),
			PAINT_OFFSET_X, y += PAINT_OFFSET_Y_INCREMENT, Font.BOLD, PAINT_COLOR);

		this.drawString(String.format("@yel@Pid: @cya@%d", this.extension.getMobServerIndex(this.extension.getPlayer())),
			PAINT_OFFSET_X, y += PAINT_OFFSET_Y_INCREMENT, Font.BOLD, PAINT_COLOR);

		this.drawString("", PAINT_OFFSET_X, y += PAINT_OFFSET_Y_INCREMENT, Font.BOLD, PAINT_COLOR);

		if (!this.receiver) {
			this.drawString(String.format("@yel@Item: @whi@%s", getItemNameId(this.itemId)),
				PAINT_OFFSET_X, y += PAINT_OFFSET_Y_INCREMENT, Font.BOLD, PAINT_COLOR);
		}

		this.drawString(String.format("@yel@%s: @whi@%s @cya@(@whi@%s items@cya@/@whi@hr@cya@)",
				this.receiver ? "Received" : "Traded", this.itemsTraded, getUnitsPerHour(this.itemsTraded, secondsElapsed)),
			PAINT_OFFSET_X, y += PAINT_OFFSET_Y_INCREMENT, Font.BOLD, PAINT_COLOR);

		if (this.itemsRemaining > 0) {
			this.drawString("", PAINT_OFFSET_X, y += PAINT_OFFSET_Y_INCREMENT, Font.BOLD, PAINT_COLOR);

			this.drawString(String.format("@yel@Remaining: @whi@%d", this.itemsRemaining),
				PAINT_OFFSET_X, y += PAINT_OFFSET_Y_INCREMENT, Font.BOLD, PAINT_COLOR);

			this.drawString(String.format("@yel@Est. Time: @whi@%s",
					getTTL(this.itemsTraded, this.itemsRemaining, secondsElapsed)),
				PAINT_OFFSET_X, y + PAINT_OFFSET_Y_INCREMENT, Font.BOLD, PAINT_COLOR);
		}
	}

	@Override
	public void onTradeRequest(final String playerName) {
		if (this.rsn.isEmpty()) {
			this.rsn = playerName;
		}

		if (!playerName.equalsIgnoreCase(this.rsn) || this.playerBusy()) {
			return;
		}

		final int[] player = this.getPlayerByName(this.rsn);

		if (player[0] == -1) {
			return;
		}

		this.requestTrade(this.getPlayerPID(player[0]));
	}

	private int bank() {
		if (!this.isBanking()) {
			return this.openBankChest();
		}

		if (this.receiver) {
			if (System.currentTimeMillis() > this.bankTimeout && this.getInventoryCount() != 0) {
				this.deposit(this.getInventoryId(0), TOTAL_TRADE_SIZE);
				this.bankTimeout = System.currentTimeMillis() + TIMEOUT_THREE_SECONDS;
			}
		} else {
			if (System.currentTimeMillis() > this.bankTimeout && this.getInventoryCount() == 0) {
				this.itemsRemaining = this.getBankItemIdCount(this.itemId);

				if (this.itemsRemaining < TOTAL_TRADE_SIZE) {
					if (++this.itemIdIndex == this.itemIds.length) {
						return this.exit("Out of items to trade.");
					}

					this.itemId = this.itemIds[this.itemIdIndex];
					return 0;
				}

				this.withdraw(this.itemId, TOTAL_TRADE_SIZE);
				this.bankTimeout = System.currentTimeMillis() + TIMEOUT_THREE_SECONDS;
			}
		}

		return this.closeBankChest();
	}

	private int openBankChest() {
		if (System.currentTimeMillis() <= this.bankOpenTimeout) {
			return 0;
		}

		if (this.getX() - COORDINATE_BANK_CHEST.getX() > 1) {
			this.walkTo(COORDINATE_BANK_CHEST.getX() + 1, COORDINATE_BANK_CHEST.getY());
			return SLEEP_ONE_TICK;
		}

		if (!this.waitingForBank) {
			this.waitingForBank = true;
		}

		this.extension.createPacket(Constants.OP_OBJECT_ACTION1);
		this.extension.put2(COORDINATE_BANK_CHEST.getX());
		this.extension.put2(COORDINATE_BANK_CHEST.getY());
		this.extension.finishPacket();

		this.bankOpenTimeout = System.currentTimeMillis() + TIMEOUT_TWO_SECONDS;
		return 0;
	}

	private int closeBankChest() {
		if (System.currentTimeMillis() <= this.bankCloseTimeout) {
			return 0;
		}

		if (this.waitingForBank) {
			this.waitingForBank = false;
		}

		this.closeBank();
		this.bankCloseTimeout = System.currentTimeMillis() + TIMEOUT_ONE_SECOND;
		return 0;
	}

	private int trade() {
		final int[] player = this.getPlayerByName(this.rsn);

		if (player[0] == -1) {
			if (this.isInTradeOffer() || this.isInTradeConfirm()) {
				this.cancelTrade();
			}

			return 0;
		}

		if (this.isInTradeConfirm()) {
			return this.sendConfirmTrade();
		}

		if (this.isInTradeOffer()) {
			if (!this.receiver &&
				System.currentTimeMillis() > this.tradeOfferTimeout &&
				this.getLocalTradeItemCount() == 0) {
				this.offerItemTrade(0, MAX_TRADE_SIZE);
				this.tradeOfferTimeout = System.currentTimeMillis() + TIMEOUT_TWO_SECONDS;
			}

			return this.sendAcceptTrade();
		}

		if (this.idle) {
			return this.idle();
		}

		return this.requestTrade(this.getPlayerPID(player[0]));
	}

	private int requestTrade(final int serverIndex) {
		if (System.currentTimeMillis() <= this.tradeRequestTimeout) {
			return 0;
		}

		this.sendTradeRequest(serverIndex);
		this.tradeTimeout = System.currentTimeMillis() + MAX_TRADE_DURATION;
		this.tradeRequestTimeout = System.currentTimeMillis() + TIMEOUT_TWO_SECONDS;
		return 0;
	}

	private int sendAcceptTrade() {
		if (!this.tradeAcceptSent && !this.hasLocalAcceptedTrade()) {
			this.acceptTrade();
			this.extension.displayMessage("@or1@Trade accepted.");
			this.tradeAcceptSent = true;
		} else if (System.currentTimeMillis() > this.tradeTimeout) {
			this.cancelTrade();
		}

		return 0;
	}

	private int sendConfirmTrade() {
		if (!this.tradeConfirmSent && !this.hasLocalAcceptedTrade()) {
			this.confirmTrade();
			this.extension.displayMessage("@or2@Trade confirmed.");
			this.tradeConfirmSent = true;
		} else if (System.currentTimeMillis() > this.tradeTimeout) {
			this.cancelTrade();
		}

		return 0;
	}

	private void cancelTrade() {
		this.declineTrade();
		this.reset();
	}

	private int idle() {
		if (this.getY() != this.previousPlayerY) {
			this.idle = false;
			return 0;
		}

		if (this.previousPlayerY == COORDINATE_BANK_CHEST.getY()) {
			this.walkTo(COORDINATE_BANK_CHEST.getX() + 1, COORDINATE_BANK_CHEST.getY() + 1);
		} else {
			this.walkTo(COORDINATE_BANK_CHEST.getX() + 1, COORDINATE_BANK_CHEST.getY());
		}

		return SLEEP_ONE_TICK;
	}

	private boolean playerBusy() {
		return this.isInTradeOffer() || this.isInTradeConfirm() || this.isBanking() || this.waitingForBank || this.idle;
	}

	public int getBankItemIdCount(final int itemId) {
		int count = 0;

		for (int index = 0; index < this.extension.getBankSize(); index++) {
			if (this.extension.getBankId(index) == itemId) {
				count += this.extension.getBankStack(index);
				break;
			}
		}

		return count;
	}

	private void reset() {
		this.tradeTimeout = 0L;
		this.tradeRequestTimeout = 0L;
		this.tradeOfferTimeout = 0L;

		this.bankTimeout = 0L;
		this.bankOpenTimeout = 0L;
		this.bankCloseTimeout = 0L;

		this.extension.setInTradeOffer(false);
		this.extension.Mi = false;

		this.extension.setInTradeConfirm(false);
		this.extension.Vi = false;

		this.waitingForBank = false;
		this.tradeConfirmSent = false;
		this.tradeAcceptSent = false;
	}
}
