import com.aposbot._default.IClient;
import com.aposbot._default.IScript;
import com.aposbot._default.IScriptListener;

import java.awt.event.KeyEvent;
import java.util.HashSet;
import java.util.Set;

/**
 * Listens for client events to pass to running scripts.
 * Calls the main script loop every game tick.
 */
final class ScriptListener implements IScriptListener {
	static final String ERROR_MESSAGE = "Error processing script. Send this output to the script's author:";

	private static final ScriptListener instance = new ScriptListener();

	private final IClient client;

	private final Set<Object> despawnedNpcs = new HashSet<>();

	private IScript script;
	private String lastWord;

	private long next;

	private boolean newWord;
	private boolean running;

	private ScriptListener() {
		client = Extension.getInstance();
	}

	static IScriptListener getInstance() {
		return instance;
	}

	static boolean isRunning() {
		return instance.isScriptRunning();
	}

	static void setRunning(final boolean b) {
		instance.setScriptRunning(b);
	}

	static void runScript() {
		instance.onGameTick();
	}

	@Override
	public void onGameTick() {
		if (running) {
			if (script.isSleeping()) {
				if (newWord && (script.getFatigue() == 0 || script.isTricking())) {
					final String word = SleepListener.getInstance().getGuess();
					if (word != null && !word.equals(lastWord)) {
						System.out.println("Sending guessed word: " + word);
						client.sendCAPTCHA(word);
						lastWord = word;
						newWord = false;
					}
				}
				return;
			}
			if (System.currentTimeMillis() >= next) {
				try {
					next = (script.main() + System.currentTimeMillis());
				} catch (final Throwable t) {
					System.out.println(ERROR_MESSAGE);
					t.printStackTrace();
				}
			}
		}
	}

	@Override
	public void onPaintTick() {
		if (running) {
			try {
				script.paint();
			} catch (final Throwable t) {
				System.out.println(ERROR_MESSAGE);
				t.printStackTrace();
			}
		}
	}

	@Override
	public void onKeyPress(final KeyEvent e) {
		if (running) {
			script.onKeyPress(e);
		}
	}

	@Override
	public void onPlayerDamaged(final Object player) {
		if (!running) {
			return;
		}

		try {
			script.onPlayerDamaged(player);
		} catch (final Throwable t) {
			System.out.println(ERROR_MESSAGE);
			t.printStackTrace();
		}
	}

	@Override
	public void onNpcDamaged(final Object npc) {
		if (!running) {
			return;
		}

		try {
			script.onNpcDamaged(npc);
		} catch (final Throwable t) {
			System.out.println(ERROR_MESSAGE);
			t.printStackTrace();
		}
	}

	@Override
	public void onNpcSpawned(final Object npc) {
		if (!running) {
			return;
		}

		try {
			script.onNpcSpawned(npc);
		} catch (final Throwable t) {
			System.out.println(ERROR_MESSAGE);
			t.printStackTrace();
		}
	}

	@Override
	public void onNpcUpdate() {
		if (!running)
		{
			return;
		}

		for (int i = 0; i < client.getNpcCacheCount(); i++)
		{
			despawnedNpcs.add(client.getNpcCached(i));
		}

		for (int i = 0; i < client.getNpcCount(); i++)
		{
			despawnedNpcs.remove(client.getNpc(i));
		}

		if (despawnedNpcs.isEmpty())
		{
			return;
		}

		try {
			for (final Object npc : despawnedNpcs)
			{
				script.onNpcDespawned(npc);
			}
		} catch (final Throwable t) {
			System.out.println(ERROR_MESSAGE);
			t.printStackTrace();
		} finally {
			despawnedNpcs.clear();
		}
	}

	@Override
	public void onDeath() {
		if (!running) {
			return;
		}

		try {
			script.onDeath();
		} catch (final Throwable t) {
			System.out.println(ERROR_MESSAGE);
			t.printStackTrace();
		}
	}

	@Override
	public void onGroundItemSpawned(final int groundItemIndex) {
		if (!running) {
			return;
		}

		try {
			script.onGroundItemSpawned(groundItemIndex);
		} catch (final Throwable t) {
			System.out.println(ERROR_MESSAGE);
			t.printStackTrace();
		}
	}

	@Override
	public void onGroundItemDespawned(final int id, final int localX, final int localY) {
		if (!running) {
			return;
		}

		try {
			script.onGroundItemDespawned(id, localX + client.getAreaX(), localY + client.getAreaY());
		} catch (final Throwable t) {
			System.out.println(ERROR_MESSAGE);
			t.printStackTrace();
		}
	}

	@Override
	public void onGameMessage(final boolean flag, String s1, final int i1, final String s2, final int j1, final int k1, final String s3,
							  final String s4) {
		if (running) {
			if (s1 != null) {
				s1 = s1.replace((char) 160, ' ');
			}
			try {
				if (j1 == 1) {
					script.onPrivateMessage(s2, s1, k1 == 1, k1 >= 2);
				} else if (j1 == 0 || j1 == 3) {
					script.onServerMessage(s2);
				} else if (j1 == 4) {
					script.onChatMessage(s2, s1, k1 == 1, k1 >= 2);
				} else if (j1 == 6) {
					script.onTradeRequest(s1);
				}
			} catch (final Throwable t) {
				System.out.println(ERROR_MESSAGE);
				t.printStackTrace();
			}
		}
	}

	@Override
	public void onNewSleepWord() {
		newWord = true;
	}

	@Override
	public void setIScript(final IScript script) {
		this.script = script;
	}

	@Override
	public boolean isScriptRunning() {
		return running;
	}

	@Override
	public void setScriptRunning(final boolean b) {
		running = b;
	}

	@Override
	public String getScriptName() {
		if (script == null) {
			return "null";
		}
		return script.toString();
	}

	@Override
	public boolean hasScript() {
		return script != null;
	}

	@Override
	public void setBanned(final boolean b) {
	}

	static void message(final boolean flag, final String s1, final int i1, final String s2, final int j1, final int k1, final String s3,
						final String s4) {
		instance.onGameMessage(flag, s1, i1, s2, j1, k1, s3, s4);
	}

	static void playerDamagedHook(final ta player) {
		instance.onPlayerDamaged(player);
	}

	static void npcDamagedHook(final ta npc) {
		instance.onNpcDamaged(npc);
	}

	static void npcSpawnedHook(final ta npc) {
		instance.onNpcSpawned(npc);
	}

	static void npcUpdateHook() {
		instance.onNpcUpdate();
	}

	static void deathHook() {
		instance.onDeath();
	}

	static void groundItemSpawnedHook(final int groundItemIndex) {
		instance.onGroundItemSpawned(groundItemIndex);
	}

	static void groundItemDespawnedHook(final int id, final int localX, final int localY) {
		instance.onGroundItemDespawned(id, localX, localY);
	}
}
