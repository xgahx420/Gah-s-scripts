import com.aposbot.BotLoader;
import com.aposbot.Constants;
import com.aposbot.EntryFrame;
import com.aposbot._default.ISleepListener;
import com.stormy.ocrlib.DictSearch;
import com.stormy.ocrlib.OCR;
import com.stormy.ocrlib.SimpleImageIO;

import java.io.*;
import java.nio.file.Paths;

/**
 * Listens for sleepwords and solves the sleep CAPTCHA.
 */
final class SleepListener implements ISleepListener {
	private static final SleepListener instance = new SleepListener();

	private static final int OCR_NUM3 = 0;
	private static final int OCR_JOKER = 1;
	private static final int OCR_EXTERNAL = 2;
	private static final int OCR_MANUAL = 3;

	private static final String HC_BMP = Paths.get("HC.BMP").toString();
	private static final String SLWORD_TXT = Paths.get("slword.txt").toString();
	private static final String DICT_TXT = Constants.PATH_SLEEP.resolve("dictionary.txt").toString();
	private static final String MODEL_TXT = Constants.PATH_SLEEP.resolve("model.txt").toString();

	private OCR stormy;
	private String sleepWord;

	private File hc;
	private File slword;

	private long mod;

	private int ocrType;

	private SleepListener() {
	}

	static void newWord(final byte[] data) {
		instance.onNewWord(data);
	}

	private static void saveBitmap(final OutputStream out, final byte[] data) throws IOException {
		out.write(66);
		out.write(77);
		short var3 = 1342;
		out.write(var3 & 255);
		out.write(var3 >> 8 & 255);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		byte var10 = 62;
		out.write(var10 & 255);
		out.write(0);
		out.write(0);
		out.write(0);
		var10 = 40;
		out.write(var10 & 255);
		out.write(0);
		out.write(0);
		out.write(0);
		var3 = 256;
		out.write(0);
		out.write(var3 >> 8 & 255);
		out.write(0);
		out.write(0);
		out.write(var10 & 255);
		out.write(0);
		out.write(0);
		out.write(0);
		var10 = 1;
		out.write(var10 & 255);
		out.write(0);
		out.write(var10 & 255);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(0);
		out.write(255);
		out.write(255);
		out.write(255);
		out.write(0);
		int var4 = 9945;
		for (int var5 = 0; var5 < 40; ++var5) {
			for (int var6 = 0; var6 < 32; ++var6) {
				byte var7 = 0;
				for (int var8 = 0; var8 < 8; ++var8) {
					var7 = (byte) (2 * var7);
					if (var6 != 31 || var8 != 7) {
						if (data[var4] != 0) {
							++var7;
						}
						++var4;
					}
				}
				out.write(var7);
			}
			var4 -= 510;
		}
	}

	private static byte[] convertImage(final byte[] data) {
		int var1 = 1;
		byte var2 = 0;
		final byte[] var4 = new byte[10200];
		int var3;
		int var5;
		int var6;
		for (var3 = 0; var3 < 255; var2 = (byte) (255 - var2)) {
			var5 = data[var1++] & 255;
			for (var6 = 0; var6 < var5; ++var6) {
				var4[var3++] = var2;
			}
		}
		for (var5 = 1; var5 < 40; ++var5) {
			var6 = 0;
			while (var6 < 255) {
				final int var7 = data[var1++] & 255;
				for (int var8 = 0; var8 < var7; ++var8) {
					var4[var3] = var4[var3 - 255];
					++var3;
					++var6;
				}
				if (var6 < 255) {
					var4[var3] = (byte) (255 - var4[var3 - 255]);
					++var3;
					++var6;
				}
			}
		}
		return var4;
	}

	static SleepListener getInstance() {
		return instance;
	}

	@Override
	public void setSolver(final BotLoader bl, final String type) {
		switch (type) {
			case EntryFrame.LABEL_NUM3:
				try (final BufferedReader mr = new BufferedReader(new FileReader(MODEL_TXT));
					 final BufferedReader dr = new BufferedReader(new FileReader(DICT_TXT))) {
					stormy = new OCR(new DictSearch(dr), mr);
					ocrType = OCR_NUM3;
				} catch (final Throwable t) {
					t.printStackTrace();
					ocrType = OCR_MANUAL;
				}
				break;
			case EntryFrame.LABEL_EXTERNAL:
				hc = new File(HC_BMP);
				slword = new File(SLWORD_TXT);
				ocrType = OCR_EXTERNAL;
				break;
			case EntryFrame.LABEL_JOKER:
				hc = new File(HC_BMP);
				final Joker joker = Joker.getInstance();
				if (joker.loadNativeLibrary()) {
					joker.setFilePaths(MODEL_TXT, DICT_TXT);
					ocrType = OCR_JOKER;
				} else {
					ocrType = OCR_MANUAL;
				}
				break;
			default:
				ocrType = OCR_MANUAL;
				break;
		}
		if (ocrType != bl.getDefaultOCR()) {
			bl.setDefaultOCR(ocrType);
			bl.storeProperties(null);
		}
	}

	@Override
	public void onNewWord(final byte[] data) {
		if (ScriptListener.getInstance().isScriptRunning() && ocrType != OCR_MANUAL) {
			if (ocrType == OCR_NUM3) {
				final ByteArrayOutputStream out = new ByteArrayOutputStream(4096);
				try {
					saveBitmap(out, convertImage(data));
					sleepWord = stormy.guess(SimpleImageIO.readBMP(out.toByteArray()), true);
				} catch (final IOException ex) {
					ex.printStackTrace();
					sleepWord = null;
				}
			} else {
				if (ocrType != OCR_JOKER) {
					mod = slword.lastModified();
				}
				try (final FileOutputStream out = new FileOutputStream(hc)) {
					saveBitmap(out, convertImage(data));
					if (ocrType == OCR_JOKER) {
						sleepWord = Joker.getInstance().getGuess();
					}
				} catch (final IOException ex) {
					ex.printStackTrace();
				}
			}
			ScriptListener.getInstance().onNewSleepWord();
		}
	}

	@Override
	public String getGuess() {
		if (ocrType == OCR_EXTERNAL) {
			if (mod < slword.lastModified()) {
				sleepWord = readLine(slword);
				mod = slword.lastModified();
				return sleepWord;
			}
			return null;
		}
		return sleepWord;
	}

	private static String readLine(final File file) {
		try (final BufferedReader reader = new BufferedReader(new FileReader(file))) {
			return reader.readLine().trim();
		} catch (final Throwable t) {
			System.out.println("Error reading slword.txt: " + t);
		}
		return null;
	}
}
