package com.stormy.ocrlib.svm;

public class svm_node
        implements java.io.Serializable {

    private static final long serialVersionUID = -8153204812821965833L;
    public int index;
    public double value;
}
