package com.stormy.ocrlib;

interface JoiningCriterionT {

    boolean joinCritFunc(Region r1, Region r2);

}
