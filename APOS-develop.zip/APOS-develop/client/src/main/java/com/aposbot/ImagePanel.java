package com.aposbot;

import java.awt.*;

class ImagePanel extends Panel {
	private static final long serialVersionUID = 4557522767188007469L;

	private final Image image;

	ImagePanel(final Image image) {
		this.image = image;
	}

	@Override
	public void paint(final Graphics g) {
		super.paint(g);
		if (image != null) {
			g.drawImage(image, 0, 0, null);
		}
	}
}
