package com.aposbot;

import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;

final class ScriptClassLoader extends URLClassLoader {
	public ScriptClassLoader() throws MalformedURLException {
		super(new URL[]{Constants.PATH_SCRIPT.toUri().toURL()});
	}
}
