package com.aposbot;

import java.awt.*;
import java.io.OutputStream;

class TextAreaOutputStream extends OutputStream {
	private final TextArea area;

	TextAreaOutputStream(final TextArea area) {
		this.area = area;
	}

	@Override
	public void write(final int b) {
		area.append(new String(new byte[]{
			(byte) b
		}).intern());
	}

	@Override
	public void write(final byte[] b) {
		area.append(new String(b));
	}

	@Override
	public void write(final byte[] b, final int off, final int len) {
		area.append(new String(b, off, len));
	}
}
