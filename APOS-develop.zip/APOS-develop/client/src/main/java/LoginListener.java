import com.aposbot.Constants;
import com.aposbot._default.IClient;
import com.aposbot._default.ILoginListener;

import java.util.Locale;

/**
 * Handles auto-login.
 */
final class LoginListener implements ILoginListener {
	private static final LoginListener instance = new LoginListener();

	private final IClient client;

	private String username;
	private String password;

	private boolean enabled;
	private boolean loaded;

	private long next_attempt;

	private LoginListener() {
		client = Extension.getInstance();
	}

	static void loginTick() {
		instance.onLoginTick();
	}

	static void welcomeBoxTick() {
		instance.onWelcomeBoxTick();
	}

	static void onLoginResponse(final String arg0, final String arg1) {
		String message = arg0 + " " + arg1;
		System.out.println(message);
		message = message.toLowerCase(Locale.ENGLISH);
		if (message.contains("updated")) {
			System.out.println("Looks like APOS is out of date. Wait patiently for an update to be released on the forums.");
			instance.next_attempt = Long.MAX_VALUE;
		} else if (message.contains("member") ||
			message.contains("stolen") ||
			message.contains("locked") ||
			message.contains("banned") ||
			message.contains("customer support") ||
			message.contains("new players") ||
			message.contains("cannot access") ||
			message.contains("disabled")) {
			System.out.println("Looks like we got banned, waiting a random 5-7 minutes");
			instance.next_attempt = System.currentTimeMillis() + 300000L + Constants.RANDOM.nextInt(120000);
		} else {
			instance.next_attempt = System.currentTimeMillis() + 4000L + Constants.RANDOM.nextInt(8000);
		}
	}

	@Override
	public void onLoginTick() {
		if (System.currentTimeMillis() < next_attempt) {
			return;
		}

		if (!loaded) {
			final String font = ClientInit.getBotLoader().getFont();
			if (font != null) {
				System.out.println("Setting font to " + font);
				client.setFont(font);
			}
			StaticAccess.setStrings();
			loaded = true;
		}

		if (enabled && username != null) {
			final int len = password.length();
			final StringBuilder b = new StringBuilder(len);
			for (int i = 0; i < len; i++) {
				b.append('*');
			}
			System.out.println("Logging in: " + username + " " + b);
			client.login(username, password);
		}
	}

	@Override
	public void onWelcomeBoxTick() {
		if (enabled) {
			client.closeWelcomeBox();
		}
		PaintListener.getInstance().resetDisplayedXp();
	}

	@Override
	public boolean isEnabled() {
		return enabled;
	}

	@Override
	public void setEnabled(final boolean b) {
		enabled = b;
		if (b) {
			next_attempt = 0;
		}
	}

	@Override
	public void setAccount(final String username, final String password) {
		this.username = username;
		this.password = password;
	}

	@Override
	public void setBanned(final boolean b) {
	}

	static LoginListener getInstance() {
		return instance;
	}
}
