import com.aposbot.Constants;

import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Objects;

public abstract class AA_Script extends Script {
	protected static final DecimalFormat DECIMAL_FORMAT = new DecimalFormat("#,##0");

	protected static final int[] NPC_IDS_BANKER = new int[]{95, 224, 268, 485, 540, 617, 792};
	protected static final int[] OBJECT_IDS_BED = new int[]{14, 15, 1035, 1162, 1171};

	protected static final long TIMEOUT_ONE_TICK = 650L;
	protected static final long TIMEOUT_ONE_SECOND = 1000L;
	protected static final long TIMEOUT_TWO_SECONDS = 2000L;
	protected static final long TIMEOUT_THREE_SECONDS = 3000L;
	protected static final long TIMEOUT_FIVE_SECONDS = 5000L;
	protected static final long TIMEOUT_TEN_SECONDS = 10000L;

	protected static final int SLEEP_ONE_TICK = 650;
	protected static final int SLEEP_ONE_SECOND = 1000;
	protected static final int SLEEP_TWO_SECONDS = 2000;
	protected static final int SLEEP_THREE_SECONDS = 3000;
	protected static final int SLEEP_FIVE_SECONDS = 5000;
	protected static final int SLEEP_TEN_SECONDS = 10000;

	protected static final int PAINT_OFFSET_X = 312;
	protected static final int PAINT_OFFSET_X_LOOT = 140;
	protected static final int PAINT_OFFSET_Y = 48;
	protected static final int PAINT_OFFSET_Y_INCREMENT = 14;

	protected static final int MAX_INVENTORY_SIZE = 30;
	protected static final int MAX_TRADE_SIZE = 12;

	protected static final int ITEM_ID_SLEEPING_BAG = 1263;

	private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm:ss");

	protected final Extension bot;

	protected CombatStyle combatStyle = CombatStyle.STRENGTH;

	private long optionMenuTimeout;

	public AA_Script(final Extension bot) {
		super(bot);
		this.bot = bot;
	}

	protected static String toUnitsPerHour(final int processed, final long time) {
		if (processed == 0) {
			return "0";
		}

		final double amount = processed * 60.0 * 60.0;
		final double seconds = (System.currentTimeMillis() - time) / 1000.0;
		return DECIMAL_FORMAT.format(amount / seconds);
	}

	protected static String toTimeToCompletion(final int processed, final int remaining, final long time) {
		if (processed == 0) {
			return "0:00:00";
		}

		final double seconds = (System.currentTimeMillis() - time) / 1000.0;
		final double secondsPerItem = seconds / processed;
		final long ttl = (long) (secondsPerItem * remaining);
		return String.format("%d:%02d:%02d", ttl / 3600, (ttl % 3600) / 60, (ttl % 60));
	}

	protected static String toDuration(final long time) {
		final long seconds = (System.currentTimeMillis() - time) / 1000;
		return String.format("%d:%02d:%02d", seconds / 3600, (seconds % 3600) / 60, (seconds % 60));
	}

	protected static String getLocalDateTime() {
		return LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS).format(DATE_TIME_FORMATTER);
	}

	@Override
	public abstract void init(final String parameters);

	@Override
	public abstract int main();

	@Override
	public void onServerMessage(final String message) {
		if (message.endsWith("moment")) {
			optionMenuTimeout = 0L;
		}
	}

	@Override
	public void onDeath() {
		setAutoLogin(false);
		stopScript();
		System.out.println("Oh dear, you are dead.");
	}

	@Override
	public void walkTo(final int x, final int y) {
		bot.walkDirectly(x - bot.getAreaX(), y - bot.getAreaY(), false);
		bot.setActionInd(24);
	}

	@Override
	public void useItemOnObject(final int inventoryIndex, final int x, final int y) {
		final int localX = x - bot.getAreaX();
		final int localY = y - bot.getAreaY();

		int objectId = -1;
		int objectDirection = -1;

		for (int index = 0; index < bot.getObjectCount(); index++) {
			if (bot.getObjectLocalX(index) == localX && bot.getObjectLocalY(index) == localY) {
				objectId = bot.getObjectId(index);
				objectDirection = bot.getObjectDir(index);
				break;
			}
		}

		if (objectId == -1 || objectDirection == -1) {
			return;
		}

		bot.walkToObject(localX, localY, objectDirection, objectId);
		bot.createPacket(Constants.OP_OBJECT_USEWITH);
		bot.put2(x);
		bot.put2(y);
		bot.put2(inventoryIndex);
		bot.finishPacket();
	}

	@Override
	public void atObject(final int x, final int y) {
		final int index = getObjectIndex(x, y);

		if (index == -1) {
			return;
		}

		bot.walkToObject(x - bot.getAreaX(), y - bot.getAreaY(), bot.getObjectDir(index),
			bot.getObjectId(index));

		bot.createPacket(Constants.OP_OBJECT_ACTION1);
		bot.put2(x);
		bot.put2(y);
		bot.finishPacket();
	}

	@Override
	public void atObject2(final int x, final int y) {
		final int index = getObjectIndex(x, y);

		if (index == -1) {
			return;
		}

		bot.walkToObject(x - bot.getAreaX(), y - bot.getAreaY(), bot.getObjectDir(index),
			bot.getObjectId(index));

		bot.createPacket(Constants.OP_OBJECT_ACTION2);
		bot.put2(x);
		bot.put2(y);
		bot.finishPacket();
	}

	@Override
	public void atWallObject(final int x, final int y) {
		final int wallObjectIndex = getWallObjectIndex(x, y);

		if (wallObjectIndex == -1) {
			return;
		}

		final int dir = bot.getBoundDir(wallObjectIndex);

		bot.walkToBound(x - bot.getAreaX(), y - bot.getAreaY(), dir);

		bot.createPacket(Constants.OP_BOUND_ACTION1);
		bot.put2(x);
		bot.put2(y);
		bot.put1(dir);
		bot.finishPacket();
	}

	@Override
	public void atWallObject2(final int x, final int y) {
		final int wallObjectIndex = getWallObjectIndex(x, y);

		if (wallObjectIndex == -1) {
			return;
		}

		final int dir = bot.getBoundDir(wallObjectIndex);

		bot.walkToBound(x - bot.getAreaX(), y - bot.getAreaY(), dir);

		bot.createPacket(Constants.OP_BOUND_ACTION2);
		bot.put2(x);
		bot.put2(y);
		bot.put1(dir);
		bot.finishPacket();
	}

	@Override
	public void deposit(final int itemId, final int amount) {
		bot.createPacket(Constants.OP_BANK_DEPOSIT);
		bot.put2(itemId);
		bot.put4(amount);
		bot.put4(-2023406815);
		bot.finishPacket();
	}

	@Override
	public void withdraw(final int itemId, final int amount) {
		bot.createPacket(Constants.OP_BANK_WITHDRAW);
		bot.put2(itemId);
		bot.put4(amount);
		bot.put4(305419896);
		bot.finishPacket();
	}

	@Override
	public boolean hasBankItem(final int itemId) {
		for (int index = 0; index < bot.getBankSize(); index++) {
			if (bot.getBankId(index) == itemId && bot.getBankStack(index) > 0) {
				return true;
			}
		}

		return false;
	}

	@Override
	public void closeBank() {
		bot.createPacket(Constants.OP_BANK_CLOSE);
		bot.finishPacket();
		bot.setBankVisible(false);
	}

	@Override
	public void sellShopItem(final int shopIndex, final int amount) {
		bot.createPacket(Constants.OP_SHOP_SELL);
		bot.put2(bot.getShopId(shopIndex));
		bot.put2(bot.getShopStack(shopIndex));
		bot.put2(amount);
		bot.finishPacket();
	}

	@Override
	public String getItemName(final int itemId) {
		return getItemNameId(itemId);
	}

	protected final int getWallObjectIndex(final int x, final int y) {
		for (int index = 0; index < bot.getBoundCount(); index++) {
			if (bot.getBoundLocalX(index) == (x - bot.getAreaX()) && bot.getBoundLocalY(index) == (y - bot.getAreaY())) {
				return index;
			}
		}

		return -1;
	}

	protected final int getObjectIndex(final int x, final int y) {
		for (int index = 0; index < bot.getObjectCount(); index++) {
			if (bot.getObjectLocalX(index) == (x - bot.getAreaX()) && bot.getObjectLocalY(index) == (y - bot.getAreaY())) {
				return index;
			}
		}

		return -1;
	}

	@Override
	public final String toString() {
		return getClass().getSimpleName();
	}

	protected final boolean isDead() {
		return bot.isDeathScreen() ||
			bot.getLocalX() < 0 || bot.getLocalX() > 96 ||
			bot.getLocalY() < 0 || bot.getLocalY() > 96;
	}

	protected final double getTotalCombatXp() {
		int total = 0;

		for (int i = 0; i < 4; i++) {
			total += bot.getExperience(i);
		}

		return total;
	}

	protected final boolean isInventoryFull() {
		return bot.getInventorySize() == MAX_INV_SIZE;
	}

	protected final boolean isInventoryEmpty() {
		return bot.getInventorySize() == 0;
	}

	protected final int getInventoryEmptyCount() {
		return MAX_INV_SIZE - bot.getInventorySize();
	}

	protected final boolean hasInventoryItem(final int[] itemIds) {
		for (final int itemId : itemIds) {
			for (int index = 0; index < bot.getInventorySize(); index++) {
				if (bot.getInventoryId(index) == itemId) {
					return true;
				}
			}
		}

		return false;
	}

	protected final boolean isItemIdEquipped(final int itemId) {
		for (int index = 0; index < bot.getInventorySize(); index++) {
			if (bot.getInventoryId(index) == itemId) {
				return bot.isEquipped(index);
			}
		}

		return false;
	}

	protected final int openBank() {
		return openInterface(0, NPC_IDS_BANKER);
	}

	private int openInterface(final int optionIndex, final int[] npcs) {
		if (bot.isDialogVisible()) {
			bot.createPacket(Constants.OP_DIALOG_ANSWER);
			bot.put1(optionIndex);
			bot.finishPacket();
			bot.setDialogVisible(false);
			optionMenuTimeout = System.currentTimeMillis() + TIMEOUT_FIVE_SECONDS;
			return 0;
		}

		if (System.currentTimeMillis() <= optionMenuTimeout) {
			return 0;
		}

		final Object npc = getNearestNpcNotTalking(npcs);

		if (npc == null) {
			return 0;
		}

		if (distanceTo(npc) > 2) {
			walkTo(npc);
			return SLEEP_ONE_TICK;
		}

		talkToNpc(npc);
		optionMenuTimeout = System.currentTimeMillis() + TIMEOUT_FIVE_SECONDS;
		return 0;
	}

	protected final Object getNearestNpcNotTalking(final int[] npcIds) {
		return getNearestNpc(npcIds, false, true);
	}

	protected int distanceTo(final Object character) {
		return distanceTo(getX(character), getY(character), getPlayerX(), getPlayerY());
	}

	protected final void walkTo(final Object character) {
		bot.walkDirectly(bot.getMobLocalX(character), bot.getMobLocalY(character), true);
		bot.setActionInd(24);
	}

	protected final void talkToNpc(final Object npc) {
		bot.walkDirectly(bot.getMobLocalX(npc), bot.getMobLocalY(npc), true);
		bot.createPacket(Constants.OP_NPC_TALK);
		bot.put2(bot.getMobServerIndex(npc));
		bot.finishPacket();
	}

	protected final Object getNearestNpc(final int[] npcIds, final boolean notInCombat, final boolean notTalking) {
		Object nearestNpc = null;

		int currentDistance = Integer.MAX_VALUE;

		final int playerX = getPlayerX();
		final int playerY = getPlayerY();

		for (int index = 0; index < bot.getNpcCount(); index++) {
			final Object npc = bot.getNpc(index);

			if (!inArray(npcIds, bot.getNpcId(npc)) ||
				(notInCombat && isInCombat(npc)) ||
				(notTalking && isTalking(npc))) {
				continue;
			}

			final int npcX = bot.getMobLocalX(npc) + bot.getAreaX();
			final int npcY = bot.getMobLocalY(npc) + bot.getAreaY();

			final int distance = distanceTo(npcX, npcY, playerX, playerY);

			if (distance < currentDistance) {
				nearestNpc = npc;
				currentDistance = distance;
			}
		}

		return nearestNpc;
	}

	protected int getX(final Object character) {
		return bot.getMobLocalX(character) + bot.getAreaX();
	}

	protected int getY(final Object character) {
		return bot.getMobLocalY(character) + bot.getAreaY();
	}

	protected final int getPlayerX() {
		return bot.getLocalX() + bot.getAreaX();
	}

	protected final int getPlayerY() {
		return bot.getLocalY() + bot.getAreaY();
	}

	protected final boolean isInCombat(final Object character) {
		return bot.isMobInCombat(character);
	}

	protected final boolean isTalking(final Object character) {
		return bot.isMobTalking(character);
	}

	protected final int openShop(final int... shopkeepers) {
		return openInterface(0, shopkeepers);
	}

	protected final int openShop(final int optionIndex, final int[] shopkeepers) {
		return openInterface(optionIndex, shopkeepers);
	}

	protected final int sleep() {
		final int index = getInventoryItemIndex(ITEM_ID_SLEEPING_BAG);

		if (index == -1) {
			return exit("Sleeping bag missing from inventory.");
		}

		useItem(index);
		return SLEEP_ONE_SECOND;
	}

	protected final int getInventoryItemIndex(final int itemId) {
		for (int index = 0; index < bot.getInventorySize(); index++) {
			if (bot.getInventoryId(index) == itemId) {
				return index;
			}
		}

		return -1;
	}

	protected final int exit(final String reason) {
		bot.setAutoLogin(false);
		bot.stopScript();
		System.err.println(reason);
		return 0;
	}

	protected final int getInventoryItemIndex(final int[] itemIds) {
		for (final int itemId : itemIds) {
			for (int index = 0; index < bot.getInventorySize(); index++) {
				if (bot.getInventoryId(index) == itemId) {
					return index;
				}
			}
		}

		return -1;
	}

	protected final int getBaseHits() {
		return bot.getBaseLevel(3);
	}

	protected final int getCurrentHits() {
		return bot.getCurrentLevel(3);
	}

	protected final int getCurrentHits(final java.lang.Object character) {
		return ((ta) character).B;
	}

	protected final String getName(final java.lang.Object character) {
		final String name = ((ta) character).c;

		if (name == null) {
			return null;
		}

		return name.replace((char) 160, ' ');
	}

	protected final int getWaypointX(final java.lang.Object character) {
		return ((ta) character).i;
	}

	protected final int getWaypointY(final java.lang.Object character) {
		return ((ta) character).K;
	}

	protected final void useObject1(final int x, final int y) {
		bot.createPacket(Constants.OP_OBJECT_ACTION1);
		bot.put2(x);
		bot.put2(y);
		bot.finishPacket();
	}

	protected final void useObject2(final int x, final int y) {
		bot.createPacket(Constants.OP_OBJECT_ACTION2);
		bot.put2(x);
		bot.put2(y);
		bot.finishPacket();
	}

	protected final void useWithObject(final int inventoryIndex, final int x, final int y) {
		bot.createPacket(Constants.OP_OBJECT_USEWITH);
		bot.put2(x);
		bot.put2(y);
		bot.put2(inventoryIndex);
		bot.finishPacket();
	}

	protected final void takeGroundItem(final int itemId, final int x, final int y) {
		bot.createPacket(Constants.OP_GITEM_TAKE);
		bot.put2(x);
		bot.put2(y);
		bot.put2(itemId);
		bot.finishPacket();
	}

	protected final boolean hasTradeItem(final int[] itemIds) {
		for (final int itemId : itemIds) {
			for (int index = 0; index < bot.getLocalTradeItemCount(); index++) {
				if (bot.getLocalTradeItemId(index) == itemId) {
					return true;
				}
			}
		}

		return false;
	}

	protected final int getTradeItemIdCount(final int itemId) {
		int count = 0;

		for (int index = 0; index < bot.getLocalTradeItemCount(); index++) {
			if (bot.getLocalTradeItemId(index) == itemId) {
				count += bot.getLocalTradeItemStack(index);
			}
		}

		return count;
	}

	protected final void offerTradeItemId(final int itemId, final int amount) {
		final int inventoryIndex = getInventoryIndex(itemId);

		if (inventoryIndex == -1) {
			return;
		}

		bot.offerItemTrade(inventoryIndex, amount);
	}

	protected final void removeTradeItemId(final int itemId, final int amount) {
		final int tradeIndex = getTradeItemIndex(itemId);

		if (tradeIndex == -1) {
			return;
		}

		removeTradeItem(tradeIndex, amount);
	}

	protected final int getTradeItemIndex(final int itemId) {
		for (int index = 0; index < bot.getLocalTradeItemCount(); index++) {
			if (bot.getLocalTradeItemId(index) == itemId) {
				return index;
			}
		}

		return -1;
	}

	protected final void removeTradeItem(final int tradeIndex, final int amount) {
		bot.c(amount, (byte) 124, tradeIndex);
	}

	protected final double getSkillExperience(final int skillId) {
		return bot.getExperience(skillId);
	}

	protected final int getFatiguePercent() {
		return (int) bot.getFatigue();
	}

	protected final boolean isBankOpen() {
		return bot.isBankVisible();
	}

	protected final boolean isInCombat() {
		return bot.getCombatTimer() == 499;
	}

	protected final int getBankItemIdCount(final int itemId) {
		int count = 0;

		for (int index = 0; index < bot.getBankSize(); index++) {
			if (bot.getBankId(index) == itemId) {
				count += bot.getBankStack(index);
				break;
			}
		}

		return count;
	}

	protected final int getBankItemIdCount(final int[] itemIds) {
		int count = 0;

		for (final int itemId : itemIds) {
			for (int index = 0; index < bot.getBankSize(); index++) {
				if (bot.getBankId(index) == itemId) {
					count += bot.getBankStack(index);
					break;
				}
			}
		}

		return count;
	}

	protected final int getBaseSkillLevel(final int skillId) {
		return bot.getBaseLevel(skillId);
	}

	protected final int getObjectId(final int x, final int y) {
		for (int index = 0; index < bot.getObjectCount(); index++) {
			if (bot.getObjectLocalX(index) == (x - bot.getAreaX()) && bot.getObjectLocalY(index) == (y - bot.getAreaY())) {
				return bot.getObjectId(index);
			}
		}

		return -1;
	}

	protected final int getWallObjectId(final int x, final int y) {
		for (int index = 0; index < bot.getBoundCount(); index++) {
			if (bot.getBoundLocalX(index) == (x - bot.getAreaX()) && bot.getBoundLocalY(index) == (y - bot.getAreaY())) {
				return bot.getBoundId(index);
			}
		}

		return -1;
	}

	protected final void answerOptionMenu(final int menuIndex) {
		bot.createPacket(Constants.OP_DIALOG_ANSWER);
		bot.put1(menuIndex);
		bot.finishPacket();
		bot.setDialogVisible(false);
	}

	protected final Object getNearestNpcNotInCombat(final int npcId) {
		return getNearestNpc(npcId, true, false);
	}

	protected final Object getNearestNpc(final int npcId, final boolean notInCombat, final boolean notTalking) {
		Object nearestNpc = null;

		int currentDistance = Integer.MAX_VALUE;

		final int playerX = getPlayerX();
		final int playerY = getPlayerY();

		for (int index = 0; index < bot.getNpcCount(); index++) {
			final Object npc = bot.getNpc(index);

			if (bot.getNpcId(npc) != npcId ||
				(notInCombat && isInCombat(npc)) ||
				(notTalking && isTalking(npc))) {
				continue;
			}

			final int npcX = bot.getMobLocalX(npc) + bot.getAreaX();
			final int npcY = bot.getMobLocalY(npc) + bot.getAreaY();

			final int distance = distanceTo(npcX, npcY, playerX, playerY);

			if (distance < currentDistance) {
				nearestNpc = npc;
				currentDistance = distance;
			}
		}

		return nearestNpc;
	}

	protected final Object getNearestNpcNotInCombat(final int[] npcIds) {
		return getNearestNpc(npcIds, true, false);
	}

	protected final Object getNearestNpcNotTalking(final int npcId) {
		return getNearestNpc(npcId, false, true);
	}

	protected final boolean isOptionMenuOpen() {
		return bot.isDialogVisible();
	}

	protected final void castOnNpc(final int spellId, final Object npc) {
		bot.walkDirectly(bot.getMobLocalX(npc), bot.getMobLocalY(npc), true);
		bot.createPacket(Constants.OP_NPC_CAST);
		bot.put2(bot.getMobServerIndex(npc));
		bot.put2(spellId);
		bot.finishPacket();
	}

	protected final void attackNpc(final Object npc) {
		bot.walkDirectly(bot.getMobLocalX(npc), bot.getMobLocalY(npc), true);
		bot.createPacket(Constants.OP_NPC_ATTACK);
		bot.put2(bot.getMobServerIndex(npc));
		bot.finishPacket();
	}

	protected final int getInventoryItemIdCount(final int itemId) {
		int count = 0;

		for (int index = 0; index < bot.getInventorySize(); index++) {
			if (bot.getInventoryId(index) == itemId) {
				if (isItemStackableId(itemId)) {
					count += bot.getInventoryStack(index);
				} else {
					count++;
				}
			}
		}

		return count;
	}

	protected final int getInventoryItemCount() {
		return bot.getInventorySize();
	}

	protected final int getInventoryItemId(final int inventoryIndex) {
		return bot.getInventoryId(inventoryIndex);
	}

	protected final int getInventoryItemCount(final int inventoryIndex) {
		return bot.getInventoryStack(inventoryIndex);
	}

	protected final int getShopItemCount(final int shopIndex) {
		return bot.getShopStack(shopIndex);
	}

	protected final int getOptionMenuCount() {
		return bot.getDialogOptionCount();
	}

	protected final void useItemOnNpc(final int inventoryIndex, final Object npc) {
		bot.walkDirectly(bot.getMobLocalX(npc), bot.getMobLocalY(npc), true);
		bot.createPacket(Constants.OP_NPC_USEWITH);
		bot.put2(bot.getMobServerIndex(npc));
		bot.put2(inventoryIndex);
		bot.finishPacket();
	}

	protected final int getShopItemIndex(final int itemId) {
		for (int index = 0; index < bot.getShopSize(); index++) {
			if (bot.getShopId(index) == itemId) {
				return index;
			}
		}

		return -1;
	}

	protected final Coordinate getWalkableCoordinate() {
		int x;
		int y;

		for (int i = -1; i <= 1; i++) {
			x = getX() + i;

			for (int j = -1; j <= 1; j++) {
				y = getY() + j;

				if (i == 0 && j == 0) {
					continue;
				}

				if (isReachable(x, y) && !isObjectAt(x, y)) {
					return new Coordinate(x, y);
				}
			}
		}

		return null;
	}

	protected enum CombatStyle {
		CONTROLLED(0),
		STRENGTH(1),
		ATTACK(2),
		DEFENSE(3);

		private final int index;

		CombatStyle(final int index) {
			this.index = index;
		}

		@Override
		public String toString() {
			return name().charAt(0) + name().substring(1).toLowerCase();
		}

		public int getIndex() {
			return index;
		}
	}

	protected enum Skill {
		ATTACK(0),
		DEFENSE(1),
		STRENGTH(2),
		HITS(3),
		RANGED(4),
		PRAYER(5),
		MAGIC(6),
		COOKING(7),
		WOODCUT(8),
		FLETCHING(9),
		FISHING(10),
		FIREMAKING(11),
		CRAFTING(12),
		SMITHING(13),
		MINING(14),
		HERBLAW(15),
		AGILITY(16),
		THIEVING(17);

		private final int index;

		Skill(final int index) {
			this.index = index;
		}

		@Override
		public String toString() {
			return name().charAt(0) + name().substring(1).toLowerCase();
		}

		public int getIndex() {
			return index;
		}
	}

	protected enum Food {
		NONE(-1, 0, "None"),
		SHRIMP(350, 3, "Shrimp"),
		ANCHOVIES(352, 1, "Anchovies"),
		SARDINE(355, 4, "Sardine"),
		HERRING(362, 5, "Herring"),
		GIANT_CARP(718, 6, "Giant Carp"),
		MACKEREL(553, 6, "Mackerel"),
		TROUT(359, 7, "Trout"),
		COD(551, 7, "Cod"),
		PIKE(364, 8, "Pike"),
		SALMON(357, 9, "Salmon"),
		TUNA(367, 10, "Tuna"),
		LOBSTER(373, 12, "Lobster"),
		BASS(555, 13, "Bass"),
		SWORDFISH(370, 14, "Swordfish"),
		SHARK(546, 20, "Shark"),
		SEA_TURTLE(1193, 20, "Sea Turtle"),
		MANTA_RAY(1191, 20, "Manta Ray");

		private final int id;
		private final int healAmount;
		private final String name;

		Food(final int id, final int healAmount, final String name) {
			this.id = id;
			this.healAmount = healAmount;
			this.name = name;
		}

		@Override
		public String toString() {
			return name;
		}

		public int getId() {
			return id;
		}

		public int getHealAmount() {
			return healAmount;
		}
	}

	protected interface RSObject {
		int getId();

		Coordinate getCoordinate();
	}

	protected interface RSArea {
		default boolean contains(final int x, final int y) {
			return x >= getLowerBoundingCoordinate().getX() && x <= getUpperBoundingCoordinate().getX() &&
				y >= getLowerBoundingCoordinate().getY() && y <= getUpperBoundingCoordinate().getY();
		}

		Coordinate getLowerBoundingCoordinate();

		Coordinate getUpperBoundingCoordinate();
	}

	protected static final class Coordinate {
		private int x;

		private int y;

		public Coordinate(final int x, final int y) {
			this.x = x;
			this.y = y;
		}

		public boolean equals(final Object o) {
			if (o == this) {
				return true;
			}
			if (!(o instanceof Coordinate)) {
				return false;
			}
			final Coordinate other = (Coordinate) o;
			if (getX() != other.getX()) {
				return false;
			}
			return getY() == other.getY();
		}

		public int hashCode() {
			final int PRIME = 59;
			int result = 1;
			result = result * PRIME + getX();
			result = result * PRIME + getY();
			return result;
		}

		public String toString() {
			return "AA_Script.Coordinate(x=" + getX() + ", y=" + getY() + ")";
		}

		public int getX() {
			return x;
		}

		public void setX(final int x) {
			this.x = x;
		}

		public int getY() {
			return y;
		}

		public void setY(final int y) {
			this.y = y;
		}

		public void set(final int x, final int y) {
			this.x = x;
			this.y = y;
		}
	}

	protected static final class Spawn implements Comparable<Spawn> {
		private final Coordinate coordinate;

		private long timestamp;

		public Spawn(final Coordinate coordinate, final long timestamp) {
			this.coordinate = coordinate;
			this.timestamp = timestamp;
		}

		@Override
		public int compareTo(final Spawn spawn) {
			return Long.compare(timestamp, spawn.timestamp);
		}

		public boolean equals(final Object o) {
			if (o == this) {
				return true;
			}
			if (!(o instanceof Spawn)) {
				return false;
			}
			final Spawn other = (Spawn) o;
			final Object this$coordinate = getCoordinate();
			final Object other$coordinate = other.getCoordinate();
			if (!Objects.equals(this$coordinate, other$coordinate)) {
				return false;
			}
			return getTimestamp() == other.getTimestamp();
		}

		public int hashCode() {
			final int PRIME = 59;
			int result = 1;
			final Object $coordinate = getCoordinate();
			result = result * PRIME + ($coordinate == null ? 43 : $coordinate.hashCode());
			final long $timestamp = getTimestamp();
			result = result * PRIME + (int) ($timestamp >>> 32 ^ $timestamp);
			return result;
		}

		public String toString() {
			return "AA_Script.Spawn(coordinate=" + getCoordinate() + ", timestamp=" + getTimestamp() + ")";
		}

		public Coordinate getCoordinate() {
			return coordinate;
		}

		public long getTimestamp() {
			return timestamp;
		}

		public void setTimestamp(final long timestamp) {
			this.timestamp = timestamp;
		}
	}
}
