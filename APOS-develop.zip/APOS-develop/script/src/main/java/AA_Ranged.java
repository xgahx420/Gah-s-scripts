/**
 * A script for Ranging npcs.
 * Start script near the npc to be ranged.
 * <p>
 * Required Parameter:
 * <npcId>
 *
 * @Author Chomp
 */
public class AA_Ranged extends AA_Script {
	private static final int MAXIMUM_FATIGUE = 100;

	private double initialRangedXp;

	private long startTime;

	private int npcId;

	private int startX;
	private int startY;

	private boolean idle;

	public AA_Ranged(final Extension ex) {
		super(ex);
	}

	@Override
	public void init(final String parameters) {
		if (parameters.isEmpty()) {
			throw new SecurityException("Missing npc id parameter.");
		}

		npcId = Integer.parseInt(parameters);

		startX = getPlayerX();
		startY = getPlayerY();

		initialRangedXp = getSkillExperience(Skill.RANGED.getIndex());
		startTime = System.currentTimeMillis();
	}

	@Override
	public int main() {
		if (idle) {
			if (getPlayerX() == startX && getPlayerY() == startY) {
				final Coordinate coordinate = getWalkableCoordinate();

				if (coordinate != null) {
					walkTo(coordinate.getX(), coordinate.getY());
					return SLEEP_ONE_TICK;
				}
			}

			idle = false;
		}

		if (getFatiguePercent() >= MAXIMUM_FATIGUE) {
			return sleep();
		}

		if (distanceTo(startX, startY) > 1) {
			walkTo(startX, startY);
			return SLEEP_ONE_TICK;
		}

		final Object npc = getNearestNpc(npcId, false, false);

		if (npc != null) {
			attackNpc(npc);
			return SLEEP_ONE_TICK;
		}

		return 0;
	}

	@Override
	public void onServerMessage(final String message) {
		if (message.endsWith("area")) {
			idle = true;
		} else if (message.endsWith("ammo!")) {
			exit("Out of ammo.");
		} else {
			super.onServerMessage(message);
		}
	}

	@Override
	public void paint() {
		int y = PAINT_OFFSET_Y;

		bot.drawString("@yel@Ranged", PAINT_OFFSET_X, y, 1, 0);

		bot.drawString(String.format("@yel@Runtime: @whi@%s", toDuration(startTime)),
			PAINT_OFFSET_X, y += PAINT_OFFSET_Y_INCREMENT, 1, 0);

		final double xpGained = getSkillExperience(Skill.RANGED.getIndex()) - initialRangedXp;

		bot.drawString(String.format("@gre@Ranged Xp: @whi@%s @gre@(@whi@%s xp@gre@/@whi@hr@gre@)",
				DECIMAL_FORMAT.format(xpGained), toUnitsPerHour((int) xpGained, startTime)),
			PAINT_OFFSET_X, y + PAINT_OFFSET_Y_INCREMENT * 2, 1, 0);
	}
}
