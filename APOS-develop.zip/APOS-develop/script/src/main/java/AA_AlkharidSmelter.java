/**
 * Smelts bars at Alkharid furnace.
 * <p>
 * Requirements:
 * Start at Alkharid bank with sleeping bag in inventory.
 * <p>
 * Required Parameters:
 * -b,--bar <bronze|iron|silver|steel|gold|mithril|adamantite|runite>
 * <p>
 *
 * @Author Chomp
 */
public class AA_AlkharidSmelter extends AA_Script {
	private static final int MAXIMUM_DISTANCE_FROM_OBJECT = 18;
	private static final int MAXIMUM_SLEEP_WALK_FATIGUE = 80;
	private static final int MAXIMUM_FATIGUE = 99;

	private Bar bar;
	private long startTime;

	private double initialSmithingXp;

	private long depositTimeout;
	private long withdrawPrimaryOreTimeout;
	private long withdrawSecondaryOreTimeout;
	private long smeltTimeout;

	private int playerX;
	private int playerY;
	private int inventoryCount;

	private int oreRemaining;
	private int barsSmelted;

	public AA_AlkharidSmelter(final Extension extension) {
		super(extension);
	}

	@Override
	public void init(final String parameters) {
		if (parameters.isEmpty()) {
			throw new IllegalArgumentException("Missing bar type parameter.");
		}

		final String[] args = parameters.split(" ");

		for (int i = 0; i < args.length; i++) {
			switch (args[i].toLowerCase()) {
				case "-b":
				case "--bar":
					bar = Bar.valueOf(args[++i].toUpperCase());
					break;
				default:
					throw new IllegalArgumentException("Error: malformed parameters. Try again ...");
			}
		}

		if (!hasInventoryItem(ITEM_ID_SLEEPING_BAG)) {
			throw new IllegalStateException("Sleeping bag missing from inventory.");
		}

		initialSmithingXp = getAccurateXpForLevel(Skill.SMITHING.getIndex());
		startTime = System.currentTimeMillis();
	}

	@Override
	public int main() {
		playerX = getX();
		playerY = getY();
		inventoryCount = getInventoryCount();

		if (inventoryCount == 1 ||
			getInventoryId(1) != bar.primaryOreId ||
			getInventoryCount(bar.secondaryOreId) < bar.secondaryOreCount) {
			return bank();
		}

		return smelt();
	}

	@Override
	public void onServerMessage(final String message) {
		if (message.startsWith("bar", 15)) {
			barsSmelted++;
			if (oreRemaining > 0) {
				oreRemaining--;
			}
			smeltTimeout = 0L;
		} else if (message.startsWith("impure", 15)) {
			smeltTimeout = 0L;
		} else {
			super.onServerMessage(message);
		}
	}

	private int bank() {
		if (Area.BANK.contains(playerX, playerY)) {
			if (!isBanking()) {
				return openBank();
			}

			if (inventoryCount > 1 &&
				getInventoryId(1) == bar.primaryOreId &&
				getInventoryCount(bar.primaryOreId) <= bar.primaryOreWithdrawCount) {
				if (System.currentTimeMillis() <= withdrawSecondaryOreTimeout) {
					return 0;
				}

				final int secondaryOreBankCount = bankCount(bar.secondaryOreId);

				if (secondaryOreBankCount < bar.secondaryOreCount) {
					return exit(String.format("Ran out of %s.", getItemNameId(bar.secondaryOreId)));
				}

				final int primaryOreRemaining = bankCount(bar.primaryOreId);
				final int secondaryOreRemaining = secondaryOreBankCount / bar.secondaryOreCount;

				oreRemaining = Math.min(primaryOreRemaining, secondaryOreRemaining);
				withdraw(bar.secondaryOreId, bar.secondaryOreWithdrawCount);
				withdrawSecondaryOreTimeout = System.currentTimeMillis() + TIMEOUT_TWO_SECONDS;
				return 0;
			}

			if (System.currentTimeMillis() <= withdrawPrimaryOreTimeout) {
				return 0;
			}

			if (inventoryCount == 1) {
				final int primaryOreBankCount = bankCount(bar.primaryOreId);

				if (primaryOreBankCount == 0) {
					return exit(String.format("Ran out of %s.", getItemNameId(bar.primaryOreId)));
				}

				if (bar.secondaryOreId == -1) {
					oreRemaining = primaryOreBankCount;
				}

				withdraw(bar.primaryOreId, bar.primaryOreWithdrawCount);
				withdrawPrimaryOreTimeout = System.currentTimeMillis() + TIMEOUT_TWO_SECONDS;
				return 0;
			}

			if (System.currentTimeMillis() <= depositTimeout) {
				return 0;
			}

			final int itemId = getInventoryId(1);
			deposit(itemId, MAX_INV_SIZE);
			depositTimeout = System.currentTimeMillis() + TIMEOUT_TWO_SECONDS;
			return 0;
		}

		if (distanceTo(Object.BANK_DOORS.coordinate.getX(), Object.BANK_DOORS.coordinate.getY()) <= MAXIMUM_DISTANCE_FROM_OBJECT) {
			if (getObjectIdFromCoords(Object.BANK_DOORS.coordinate.getX(), Object.BANK_DOORS.coordinate.getY()) == Object.BANK_DOORS.id) {
				atObject(Object.BANK_DOORS.coordinate.getX(), Object.BANK_DOORS.coordinate.getY());
				return SLEEP_ONE_SECOND;
			}

			walkTo(Object.BANK_DOORS.coordinate.getX() + 1, Object.BANK_DOORS.coordinate.getY());
			return SLEEP_ONE_TICK;
		}

		walkTo(Object.BANK_DOORS.coordinate.getX(), Object.BANK_DOORS.coordinate.getY());
		return SLEEP_ONE_TICK;
	}

	private int smelt() {
		if (Area.FURNACE.contains(playerX, playerY)) {
			if (getFatigue() >= MAXIMUM_FATIGUE) {
				return sleep();
			}

			if (System.currentTimeMillis() <= smeltTimeout) {
				return 0;
			}

			final Coordinate furnace = Object.FURNACE.getCoordinate();

			if (playerX != furnace.getX() - 1 || playerY != furnace.getY()) {
				walkTo(furnace.getX() - 1, furnace.getY());
				return SLEEP_ONE_TICK;
			}

			bot.displayMessage("@gre@Smelting...");
			useWithObject(1, furnace.getX(), furnace.getY());
			smeltTimeout = System.currentTimeMillis() + TIMEOUT_FIVE_SECONDS;
			return 0;
		}

		if (Area.BANK.contains(playerX, playerY) &&
			getObjectIdFromCoords(Object.BANK_DOORS.coordinate.getX(), Object.BANK_DOORS.coordinate.getY()) == Object.BANK_DOORS.id) {
			atObject(Object.BANK_DOORS.coordinate.getX(), Object.BANK_DOORS.coordinate.getY());
			return SLEEP_ONE_SECOND;
		}

		walkTo(Object.FURNACE.coordinate.getX() - 1, Object.FURNACE.coordinate.getY());

		if (getFatigue() >= MAXIMUM_SLEEP_WALK_FATIGUE && isWalking()) {
			return sleep();
		}

		return SLEEP_ONE_TICK;
	}

	@Override
	public void paint() {
		int y = PAINT_OFFSET_Y;

		drawString("@yel@Alkharid Smelter", PAINT_OFFSET_X, y, 1, 0);

		drawString(String.format("@yel@Runtime: @whi@%s", toDuration(startTime)),
			PAINT_OFFSET_X, y += PAINT_OFFSET_Y_INCREMENT, 1, 0);

		drawString("", PAINT_OFFSET_X, y += PAINT_OFFSET_Y_INCREMENT, 1, 0);

		final double xpGained = getAccurateXpForLevel(Skill.SMITHING.getIndex()) - initialSmithingXp;

		drawString(String.format("@yel@Xp: @whi@%s @cya@(@whi@%s xp@cya@/@whi@hr@cya@)",
				DECIMAL_FORMAT.format(xpGained), toUnitsPerHour((int) xpGained, startTime)),
			PAINT_OFFSET_X, y += PAINT_OFFSET_Y_INCREMENT, 1, 0);

		drawString(String.format("@yel@%s: @whi@%d @cya@(@whi@%s bars@cya@/@whi@hr@cya@)",
				bar, barsSmelted, toUnitsPerHour(barsSmelted, startTime)),
			PAINT_OFFSET_X, y += PAINT_OFFSET_Y_INCREMENT, 1, 0);

		drawString(String.format("@yel@Remaining: @whi@%d", oreRemaining),
			PAINT_OFFSET_X, y += PAINT_OFFSET_Y_INCREMENT, 1, 0);

		drawString(String.format("@yel@Time remaining: @whi@%s",
				toTimeToCompletion(barsSmelted, oreRemaining, startTime)),
			PAINT_OFFSET_X, y + PAINT_OFFSET_Y_INCREMENT, 1, 0);
	}

	private enum Bar {
		BRONZE(150, 202, 1, 14, 14, "Bronze"),
		IRON(151, -1, 0, 29, 0, "Iron"),
		SILVER(383, -1, 0, 29, 0, "Silver"),
		STEEL(151, 155, 2, 9, 18, "Steel"),
		GOLD(152, -1, 0, 29, 0, "Gold"),
		MITHRIL(153, 155, 4, 5, 20, "Mithril"),
		ADAMANTITE(154, 155, 6, 4, 24, "Adamantite"),
		RUNITE(409, 155, 8, 3, 24, "Runite");

		private final int primaryOreId;
		private final int secondaryOreId;
		private final int secondaryOreCount;
		private final int primaryOreWithdrawCount;
		private final int secondaryOreWithdrawCount;
		private final String name;

		Bar(final int primaryOreId, final int secondaryOreId, final int secondaryOreCount, final int primaryOreWithdrawCount, final int secondaryOreWithdrawCount, final String name) {
			this.primaryOreId = primaryOreId;
			this.secondaryOreId = secondaryOreId;
			this.secondaryOreCount = secondaryOreCount;
			this.primaryOreWithdrawCount = primaryOreWithdrawCount;
			this.secondaryOreWithdrawCount = secondaryOreWithdrawCount;
			this.name = name;
		}

		@Override
		public String toString() {
			return name;
		}
	}

	private enum Area implements RSArea {
		BANK(new Coordinate(87, 689), new Coordinate(93, 700)),
		FURNACE(new Coordinate(82, 678), new Coordinate(86, 681));

		private final Coordinate lowerBoundingCoordinate;
		private final Coordinate upperBoundingCoordinate;

		Area(final Coordinate lowerBoundingCoordinate, final Coordinate upperBoundingCoordinate) {
			this.lowerBoundingCoordinate = lowerBoundingCoordinate;
			this.upperBoundingCoordinate = upperBoundingCoordinate;
		}

		public Coordinate getLowerBoundingCoordinate() {
			return lowerBoundingCoordinate;
		}

		public Coordinate getUpperBoundingCoordinate() {
			return upperBoundingCoordinate;
		}
	}

	private enum Object implements RSObject {
		FURNACE(118, new Coordinate(85, 679)),
		BANK_DOORS(64, new Coordinate(86, 695));

		private final int id;
		private final Coordinate coordinate;

		Object(final int id, final Coordinate coordinate) {
			this.id = id;
			this.coordinate = coordinate;
		}

		public int getId() {
			return id;
		}

		public Coordinate getCoordinate() {
			return coordinate;
		}
	}
}
